@extends('layouts.containerfluid', ['activePage' => 'executar_ordem_de_serradas', 'titlePage' => __($titleAux ?? 'Executar ordem de serradas')])
@section('containerfluid')
    @yield('padrao')
@endsection
