@extends('layouts.containerfluid', ['activePage' => 'classificacoes_blocos', 'titlePage' => __('Classificações de blocos')])
@section('containerfluid')
  @yield('padrao')
@endsection
