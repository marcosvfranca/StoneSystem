@extends('layouts.containerfluid', ['activePage' => 'motivos', 'titlePage' => __('Motivos cancelamento/não conclusão de processos')])
@section('containerfluid')
  @yield('padrao')
@endsection
