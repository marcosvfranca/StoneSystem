@extends('layouts.containerfluid', ['activePage' => 'tiposblocos', 'titlePage' => __('Material de blocos')])
@section('containerfluid')
  @yield('tiposblocos')
@endsection
