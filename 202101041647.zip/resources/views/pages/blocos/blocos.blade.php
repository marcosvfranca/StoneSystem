@extends('layouts.containerfluid', ['activePage' => 'blocos', 'titlePage' => __('Blocos/Chapas')])
@section('containerfluid')
  @yield('blocos')
@endsection
