@extends('layouts.containerfluid', ['activePage' => 'motivos', 'titlePage' => __('Motivo de cancelamentos de processos')])
@section('containerfluid')
  @yield('padrao')
@endsection
