@extends('layouts.containerfluid', ['activePage' => 'espessuras_chapas', 'titlePage' => __('Espessuras das chapas')])
@section('containerfluid')
  @yield('padrao')
@endsection
