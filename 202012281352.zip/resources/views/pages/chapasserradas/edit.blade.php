@extends('pages.chapasserradas.padrao')
@section('padrao')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Alterar chapa serrada</h4>
            </div>
            <div class="card-body">
                <form action="{{ route('chapas-serradas.update', ['chapas_serrada' => $chapasSerradas]) }}" method="post">
                    @csrf
                    @method('PUT')
                    <div class="row">
                        <div class="col-3 form-group">
                            <input type="text" autofocus class="form-control @error('numeracao') is-invalid @enderror" name="numeracao" placeholder="Numeração do bloco" value="{{ $chapasSerradas->numeracao }}">
                            @error('numeracao')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-5 form-group">
                            <select name="tipos_blocos_id" class="select2 w-100" data-placeholder="Selecione o material do bloco">
                                <option value="">Selecione o material do bloco</option>
                                @foreach($tiposBlocos as $t)
                                    <option value="{{ $t->id }}" @if($chapasSerradas->tipos_blocos_id == $t->id) selected @endif>{{ $t->descricao }}</option>
                                @endforeach
                            </select>
                            @error('tipos_blocos_id')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-4 form-group">
                            <select name="observacoes[]" class="select2 w-100" multiple="true" data-placeholder="Selecione a qualidade da serrada">
                                @foreach($observacoes as $o)
                                    <option value="{{ $o->id }}" @if($chapasSerradas->observacoes()->where('observacoes_chapas_id', $o->id)->count()) selected @endif>{{ $o->descricao }}</option>
                                @endforeach
                            </select>
                            @error('observacoes')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-12 text-center form-group">
                            <button type="submit" class="btn btn-warning"> Salvar dados da serrada</button>
                        </div>
                    </div>
                </form>
                <div class="row">
                    <div class="col-12 mt-3">
                        <h4>Cadastrar chapas na serrada</h4>
                    </div>
                    <div class="col-12" id="createItem">
                        @include('pages.chapasserradas.itens.create', ['chapasSerradas' => $chapasSerradas, 'espessuras' => $espessuras])
                    </div>
                    <div class="col-12 mt-3">
                        <h4>Chapas da serrada</h4>
                    </div>
                    <div class="col-12" id="itensChapasSerrada">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@push('js')
    <script>
        function loadItens()
        {
            $('#itensChapasSerrada').load('{{ route('itens-chapas-serradas.index') }}?serrada_id={{ $chapasSerradas->id }}');
        }
        loadItens();

        function loadFormCreate()
        {
            $('#createItem').load('{{ route('itens-chapas-serradas.create') }}?serrada_id={{ $chapasSerradas->id }}', function () {
                $(this).find('.select2').select2();
            });
        }

        function loadAll()
        {
            loadItens();
            loadFormCreate();
        }

        $(document).on('submit', '.formCreateItem, .formDeleteItem', function (e) {
            e.preventDefault();
            $form = $(this);
            formData = $form.serializeArray();
            $.ajax({
                method: $form.attr('method'),
                url: $form.attr('action'),
                data: formData,
                beforeSend: function () {
                    $form.find('button[type="submit"]').text('Carregando...');
                },
                success: function (data) {
                    $.notify({
                        icon: "equalizer",
                        message: $form.attr('data-message')
                    }, {
                        type: 'success',
                        withtimer: 500,
                        placement: {
                            from: 'top',
                            align: 'center'
                        }
                    });
                    loadAll();
                },
                complete: function () {
                    var $btn = $form.find('button[type="submit"]');
                    $btn.html($btn.attr('data-original-text'));
                },
                error: function (e) {
                    console.log(e);
                    $form.find('span.error').html('');
                    $.each(e.responseJSON.errors, function (key, value) {
                        $form.find('[name="' + key + '"]').parent().find('span.error').html(value);
                    });
                    if ($form.attr('data-message-error'))
                        $.notify({
                            icon: "equalizer",
                            message: $form.attr('data-message-error')
                        }, {
                            type: 'error',
                            withtimer: 500,
                            placement: {
                                from: 'bottom',
                                align: 'center'
                            }
                        });
                }
            });
            return false;
        });
    </script>
@endpush
@endsection
