<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TelasIniciais extends Model
{
    protected $fillable = ['nome'];
}
