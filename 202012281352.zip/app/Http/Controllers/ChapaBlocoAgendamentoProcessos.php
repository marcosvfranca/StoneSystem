<?php

namespace App\Http\Controllers;

use App\ChapaBlocoAgendamentoProcesso;
use Illuminate\Http\Request;

class ChapaBlocoAgendamentoProcessos extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ChapaBlocoAgendamentoProcesso  $chapaBlocoAgendamentoProcess
     * @return \Illuminate\Http\Response
     */
    public function show(ChapaBlocoAgendamentoProcessos $chapaBlocoAgendamentoProcess)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ChapaBlocoAgendamentoProcesso  $chapaBlocoAgendamentoProcess
     * @return \Illuminate\Http\Response
     */
    public function edit(ChapaBlocoAgendamentoProcessos $chapaBlocoAgendamentoProcess)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ChapaBlocoAgendamentoProcesso  $chapaBlocoAgendamentoProcess
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ChapaBlocoAgendamentoProcessos $chapaBlocoAgendamentoProcess)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ChapaBlocoAgendamentoProcesso  $chapaBlocoAgendamentoProcess
     * @return \Illuminate\Http\Response
     */
    public function destroy(ChapaBlocoAgendamentoProcessos $chapaBlocoAgendamentoProcess)
    {
        //
    }
}
