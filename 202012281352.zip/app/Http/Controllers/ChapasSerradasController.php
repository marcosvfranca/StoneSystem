<?php

namespace App\Http\Controllers;

use App\ChapasSerradas;
use App\EspessurasChapas;
use App\Http\Requests\ChapasSerradasRequest;
use App\ObservacoesChapas;
use App\ObservacoesChapasSerrada;
use App\TiposBlocos;
use Illuminate\Http\Request;

class ChapasSerradasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->temAcesso('chapas_serradas');
        return view('pages.chapasserradas.index', ['chapasSerradas' => ChapasSerradas::all()]);
    }

    public function pesquisa()
    {
        $data = request()->all();
        $chapasSerradas = ChapasSerradas::whereRaw('1 = 1');
        if (isset($data['q']) and $data['q'])
            $chapasSerradas
                ->where('numeracao', 'like', '%' . $data['q'] . '%');
        return view('pages.chapasserradas.table', ['chapasSerradas' => $chapasSerradas->get()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->temAcesso('chapas_serradas', 'C');
        return view('pages.chapasserradas.create', [
            'tiposBlocos' => TiposBlocos::all(),
            'observacoes' => ObservacoesChapas::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ChapasSerradasRequest $request)
    {
        $this->temAcesso('chapas_serradas', 'C');
        $data = $request->all();
        $chapaSerrada = ChapasSerradas::create($data);
        foreach ($data['observacoes'] as $o)
            ObservacoesChapasSerrada::create([
                'chapas_serradas_id' => $chapaSerrada->id,
                'observacoes_chapas_id' => $o
            ]);
        return redirect()->route('chapas-serradas.edit', ['chapas_serrada' => $chapaSerrada]);
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\ChapasSerradas  $chapasSerradas
     * @return \Illuminate\Http\Response
     */
    public function show(ChapasSerradas $chapasSerradas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ChapasSerradas  $chapasSerradas
     * @return \Illuminate\Http\Response
     */
    public function edit(ChapasSerradas $chapas_serrada)
    {
        $this->temAcesso('chapas_serradas', 'A');
        return view('pages.chapasserradas.edit', [
            'chapasSerradas' => $chapas_serrada,
            'tiposBlocos' => TiposBlocos::all(),
            'observacoes' => ObservacoesChapas::all(),
            'espessuras' => EspessurasChapas::all(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ChapasSerradas  $chapasSerradas
     * @return \Illuminate\Http\Response
     */
    public function update(ChapasSerradasRequest $request, ChapasSerradas $chapas_serrada)
    {
        $this->temAcesso('chapas_serradas', 'A');
        $data = $request->all();
        $chapas_serrada->update($data);
        ObservacoesChapasSerrada::where('chapas_serradas_id', $chapas_serrada->id)->delete();
        foreach ($data['observacoes'] as $o)
            ObservacoesChapasSerrada::create([
                'chapas_serradas_id' => $chapas_serrada->id,
                'observacoes_chapas_id' => $o
            ]);
        return redirect()->route('chapas-serradas.index')->with('status', 'Chapa serrada alterada com sucesso');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ChapasSerradas  $chapasSerradas
     * @return \Illuminate\Http\Response
     */
    public function destroy(ChapasSerradas $chapas_serrada)
    {
        $this->temAcesso('chapas_serradas', 'A');
        $chapas_serrada->deletar();
        return redirect()->route('chapas-serradas.index')->with('status', 'Chapa serrada excluída com sucesso');
    }
}
