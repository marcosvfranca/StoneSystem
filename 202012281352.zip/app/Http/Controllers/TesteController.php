<?php

namespace App\Http\Controllers;

use App\AgendamentoProcesso;
use App\Blocos;
use App\ChapaBlocoAgendamentoProcesso;
use App\ChapasBlocos;
use App\ChapasSerradas;
use App\EspessurasChapas;
use App\EstadosChapas;
use App\GruposUsuarios;
use App\Motivo;
use App\Processo;
use App\TiposBlocos;

class TesteController extends Controller
{
    public function Teste()
    {
        dd(ChapasSerradas::first()->chapas()->dd());
    }
}
