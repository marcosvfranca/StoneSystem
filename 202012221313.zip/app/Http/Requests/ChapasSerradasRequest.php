<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ChapasSerradasRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return auth()->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'numeracao' => ['required', 'max:191'],
            'qtd_chapas' => ['required'],
            'comprimento' => ['required', 'max:191'],
            'altura' => ['required', 'max:191'],
            'tipos_blocos_id' => ['required'],
            'espessuras_chapas_id' => ['required']
        ];
    }

    public function messages()
    {
        return [
            'numeracao.required' => 'Informe a numeração do bloco',
            'numeracao.max' => 'Tamanho máximo excedido',
            'qtd_chapas.required' => 'Informe a quantidade de chapas',
            'comprimento.required' => 'Informe o comprimento das chapas',
            'comprimento.max' => 'Tamanho máximo excedido',
            'altura.required' => 'Informe a altura das chapas',
            'altura.max' => 'Tamanho máximo excedido',
            'tipos_blocos_id.required' => 'Selecione o material do bloco',
            'espessuras_chapas_id.required' => 'Selecione a espessura das chapas'
        ];
    }
}
