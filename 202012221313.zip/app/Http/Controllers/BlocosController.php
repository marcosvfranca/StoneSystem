<?php

namespace App\Http\Controllers;

use App\Blocos;
use App\EspessurasChapas;
use App\EstadosChapas;
use App\Http\Requests\BlocosRequest;
use App\ObservacoesChapas;
use App\TiposBlocos;
use App\Transportadores;
use Illuminate\Support\Facades\DB;

class BlocosController extends Controller
{

    public function rindex()
    {
        return redirect('blocos');
    }

    public function index()
    {
        $this->temAcesso('blocos');
        $blocos = Blocos::all();
        return view('pages.blocos.index', ['blocos' => $blocos]);
    }

    public function pesquisa()
    {
        global $data;
        $data = request()->all();
        if(isset($data['q']) and $data['q'])
            $blocos = Blocos::where('numeracao', 'like', "%" . $data['q'] . "%")
                ->orWhereExists(function ($query) {
                    global $data;
                    $query->select(DB::raw(1))
                        ->from('tipos_blocos')
                        ->whereColumn('blocos.tipos_blocos_id', 'tipos_blocos.id')
                        ->where('tipos_blocos.descricao', 'like', "%" . $data['q'] . "%");
                })
                ->orWhereExists(function ($query) {
                    global $data;
                    $query->select(DB::raw(1))
                        ->from('transportadores')
                        ->whereColumn('blocos.transportadores_id', 'transportadores.id')
                        ->where('transportadores.nome', 'like', "%" . $data['q'] . "%")
                        ->orWhere('transportadores.placa', 'like', "%" . $data['q'] . "%");
                })
                ->orWhereExists(function ($query) {
                    $query->select(DB::raw(1))
                        ->from('chapas_blocos')
                        ->whereColumn('chapas_blocos.blocos_id', '=', 'blocos.id')
                        ->where(function ($query) {
                            global $data;
                            $query->orWhere('chapas_blocos.numeracao', 'like', "%" . $data['q'] . "%");
                            $query->orWhere('chapas_blocos.comprimento', 'like', "%" . $data['q'] . "%");
                            $query->orWhere('chapas_blocos.largura', 'like', "%" . $data['q'] . "%");
                        });
                });
        return view('pages.blocos.table', ['blocos' => $blocos->get()]);
    }

    public function cadastrar()
    {
        $this->temAcesso('blocos', 'I');
        $data = [
            'transportadores' => Transportadores::all(),
            'tiposblocos' => TiposBlocos::all()
        ];
        return view('pages.blocos.cadastrar', ['data' => $data]);
    }

    public function editar($id)
    {
        return view('pages.blocos.alterar', [
            'bloco' => Blocos::findOrFail($id),
            'transportadores' => Transportadores::all(),
            'tiposblocos' => TiposBlocos::all(),
            'espessuras' => EspessurasChapas::all(),
            'estadosChapas' => EstadosChapas::all(),
            'observacoesChapas' => ObservacoesChapas::all(),
        ]);
    }

    public function deletar($id)
    {
        $b = Blocos::findOrFail($id);
        $b->deletar();
        return $this->rindex();
    }

    public function inserir(BlocosRequest $request)
    {
        $data = $request->all();
        $bloco = $this->create($data);
        if ($this->temAcesso('blocos.inserir.redirecionar'))
            return redirect()->route('blocos.editar', ['id' => $bloco->id]);
        else
            return $this->rindex();
    }

    public function alterar(BlocosRequest $request, $id)
    {
        $data = $request->all();
        $bloco = Blocos::findOrFail($id);
        $this->update($bloco, $data);
        return $this->rindex();
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Blocos
     */
    protected function create(array $data)
    {
        return Blocos::create($data);
    }
    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Blocos
     */
    protected function update($bloco, array $data)
    {
//        dd($data);
        return $bloco->update($data);
    }
}
