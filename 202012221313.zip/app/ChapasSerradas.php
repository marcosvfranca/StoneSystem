<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChapasSerradas extends Model
{

    protected $fillable = [
        'numeracao', 'qtd_chapas', 'comprimento', 'altura', 'tipos_blocos_id', 'espessuras_chapas_id'
    ];

    public function tiposBlocos()
    {
        return $this->belongsTo(TiposBlocos::class);
    }

    public function espessura()
    {
        return $this->hasMany(EspessurasChapas::class, 'id', 'espessuras_chapas_id');
    }

}
