<?php

use Illuminate\Database\Seeder;

class TelasIniciaisSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('telas_iniciais')->insert([
            'nome' => '/home'
        ]);
        DB::table('telas_iniciais')->insert([
            'nome' => '/executar-processos'
        ]);
        DB::table('telas_iniciais')->insert([
            'nome' => '/blocos'
        ]);
        DB::table('telas_iniciais')->insert([
            'nome' => '/chapas-serradas'
        ]);
        DB::table('telas_iniciais')->insert([
            'nome' => '/chapas-serradas'
        ]);
    }
}
