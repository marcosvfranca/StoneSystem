@extends('pages.chapasserradas.padrao')
@section('padrao')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Alterar chapa serrada</h4>
            </div>
            <div class="card-body">
                <form action="{{ route('chapas-serradas.update', ['chapas_serrada' => $chapasSerradas]) }}" method="post">
                    @csrf
                    @method('PUT')
                    <div class="row">
                        <div class="col-3 form-group">
                            <input type="text" autofocus class="form-control @error('numeracao') is-invalid @enderror" name="numeracao" placeholder="Numeração do bloco" value="{{ $chapasSerradas->numeracao }}">
                            @error('numeracao')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-3 form-group">
                            <input type="number" class="form-control @error('qtd_chapas') is-invalid @enderror" name="qtd_chapas" placeholder="Quantidade chapas" value="{{ $chapasSerradas->qtd_chapas }}">
                            @error('qtd_chapas')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-3 form-group">
                            <input type="text" class="form-control @error('comprimento') is-invalid @enderror" name="comprimento" placeholder="Comprimento" value="{{ $chapasSerradas->comprimento }}">
                            @error('comprimento')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-3 form-group">
                            <input type="text" class="form-control @error('altura') is-invalid @enderror" name="altura" placeholder="Altura" value="{{ $chapasSerradas->altura }}">
                            @error('altura')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-5 form-group">
                            <select name="tipos_blocos_id" class="select2 w-100" data-placeholder="Selecione o material do bloco">
                                <option value="">Selecione o material do bloco</option>
                                @foreach($tiposBlocos as $t)
                                    <option value="{{ $t->id }}" @if($chapasSerradas->tipos_blocos_id == $t->id) selected @endif>{{ $t->descricao }}</option>
                                @endforeach
                            </select>
                            @error('tipos_blocos_id')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-5 form-group">
                            <select name="espessuras_chapas_id" class="select2 w-100" data-placeholder="Selecione a espessura das chapas">
                                <option value="">Selecione a espessura das chapas</option>
                                @foreach($espessurasChapas as $e)
                                    <option value="{{ $e->id }}" @if($chapasSerradas->espessuras_chapas_id == $e->id) selected @endif>{{ $e->descricao }}</option>
                                @endforeach
                            </select>
                            @error('espessuras_chapas_id')
                            <span class="error text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-2 form-group">
                            <button type="submit" class="btn btn-warning"> Alterar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
