    @extends('layouts.containerfluid', ['activePage' => 'tipo_material_processos', 'titlePage' => __('Material usado em processo')])
@section('containerfluid')
  @yield('padrao')
@endsection
