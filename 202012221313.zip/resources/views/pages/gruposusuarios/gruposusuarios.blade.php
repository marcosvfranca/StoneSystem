@extends('layouts.containerfluid', ['activePage' => 'gruposusuarios', 'titlePage' => __('Setores empresa')])
@section('containerfluid')
  @yield('gruposusuarios')
@endsection
