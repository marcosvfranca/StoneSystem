@extends('layouts.containerfluid', ['activePage' => 'user-management', 'titlePage' => __('Cadastro de funcionários')])
@section('containerfluid')
    @yield('padrao')
@endsection
