@extends('layouts.containerfluid', ['activePage' => 'transportadores', 'titlePage' => __('Transportadores')])
@section('containerfluid')
  @yield('transportadores')
@endsection
