@extends('layouts.containerfluid', ['activePage' => 'estados_chapas', 'titlePage' => __('Estados das chapas')])
@section('containerfluid')
  @yield('padrao')
@endsection
