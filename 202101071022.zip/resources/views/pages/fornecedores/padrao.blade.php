@extends('layouts.containerfluid', ['activePage' => 'fornecedores', 'titlePage' => __('Fornecedores')])
@section('containerfluid')
  @yield('padrao')
@endsection
