@extends('layouts.containerfluid', [
    'activePage' => 'processos',
    'titlePage' => __('Processos')])
@section('containerfluid')
  @yield('padrao')
@endsection
