<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlocosBrutos extends Model
{
    protected $fillable = [
        'numeracao', 'comprimento', 'altura', 'largura', 'transportadores_id', 'tipos_blocos_id', 'classificacoes_blocos_id', 'fornecedores_id'
    ];

    public function transportadores()
    {
        return $this->belongsTo(Transportadores::class);
    }

    public function tiposBlocos()
    {
        return $this->belongsTo(TiposBlocos::class);
    }

    public function classificacoes()
    {
        return $this->belongsTo(ClassificacoesBlocos::class, 'classificacoes_blocos_id');
    }

    public function fornecedores()
    {
        return $this->belongsTo(Fornecedores::class);
    }

}
