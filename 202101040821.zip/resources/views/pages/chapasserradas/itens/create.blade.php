<form class="card formCreateItem" action="{{ route('itens-chapas-serradas.store') }}" method="post" data-message="Chapas cadastradas com sucesso">
    <div class="card-body row">
        @csrf
        <input type="hidden" name="chapas_serradas_id" value="{{ $chapasSerradas->id }}">
        <div class="col-2 form-group">
            <input type="number" name="qtd" placeholder="Quantidade chapas" class="form-control">
            <span class="error text-danger"></span>
        </div>
        <div class="col-2 form-group">
            <input type="text" name="numeracao_inicial" placeholder="Numeração inicial" class="form-control">
            <span class="error text-danger"></span>
        </div>
        <div class="col-3 form-group">
            <select name="espessuras_chapas_id" class="select2 w-100" data-placeholder="Selecione a espessura">
                <option value="">Selecione a espessura</option>
                @foreach($espessuras as $e)
                    <option value="{{ $e->id }}">{{ $e->descricao }}</option>
                @endforeach
            </select>
            <span class="error text-danger"></span>
        </div>
        <div class="col-2 form-group">
            <input type="text" name="comprimento" placeholder="Comprimento" class="form-control">
            <span class="error text-danger"></span>
        </div>
        <div class="col-2 form-group">
            <input type="text" name="altura" placeholder="Altura" class="form-control">
            <span class="error text-danger"></span>
        </div>
        <div class="col-2 form-group">
            <button type="submit" class="btn btn-warning" data-original-text="Cadastrar">Cadastrar</button>
        </div>
    </div>
</form>
