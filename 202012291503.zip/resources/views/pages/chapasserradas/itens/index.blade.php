@if($chapas->count())
    <table class="table">
        <thead class=" text-warning">
        <tr>
            <th>
                Numeração
            </th>
            <th>
                Espessura
            </th>
            <th>
                Comprimento
            </th>
            <th>
                Altura
            </th>
            <th class="text-right">
                &nbsp;&nbsp;
            </th>
        </tr>
        </thead>
        <tbody>
        @foreach($chapas as $c)
            <tr  @if($c->espessura()->first()->cor or $c->espessura()->first()->cor_fonte) style="background-color: {{ $c->espessura()->first()->cor }};color: {{ $c->espessura()->first()->cor_fonte }};"
                @endif>
                <td>
                    {{ $c->numeracao }}
                </td>
                <td>
                    {{ $c->espessura()->first()->descricao }}
                </td>
                <td>
                    {{ $c->comprimento }}
                </td>
                <td>
                    {{ $c->altura }}
                </td>
                <td class="td-actions text-right">
                    @if(auth()->user()->temAcessoUnico('chapas_serradas', 'E'))
                        <form action="{{ route('itens-chapas-serradas.destroy', ['itens_chapas_serrada' => $c]) }}" method="POST"
                              class="d-inline formDeleteItem"
                              data-message="Item excluído com sucesso">
                            @csrf
                            @method('DELETE')
                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                    data-original-title="{{ __('Excluir') }}" title="{{ __('Excluir') }}"
                                    onclick="return confirm('Tem certeza que deseja excluir?')">
                                <i class="material-icons">delete</i>
                                {{ __('Excluir') }}
                            </button>
                        </form>
                    @endif
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
@else
    <div class="alert alert-danger">Nada encontrado...</div>
@endif
