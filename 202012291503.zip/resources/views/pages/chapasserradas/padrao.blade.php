@extends('layouts.containerfluid', [
    'activePage' => 'chapas_serradas',
    'titlePage' => __('Chapas serradas')])
@section('containerfluid')
    @yield('padrao')
@endsection
