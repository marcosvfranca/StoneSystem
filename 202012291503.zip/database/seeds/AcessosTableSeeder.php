<?php

use Illuminate\Database\Seeder;

class AcessosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        DB::table('acessos')->truncate();
        DB::table('acessos')->insert([
            'nome' => "Cadastro de funcionários",
            'unico' => "N",
            'apelido' => "profile.edit",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "DashBoard",
            'unico' => "S",
            'apelido' => "dashboard",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Menu Lateral",
            'unico' => "S",
            'apelido' => "menu_lateral",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de transportadores",
            'unico' => "N",
            'apelido' => "transportadores",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de classificação de blocos",
            'unico' => "N",
            'apelido' => "tipos-blocos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de Blocos",
            'unico' => "N",
            'apelido' => "blocos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Abrir bloco após inserir",
            'unico' => "S",
            'apelido' => "blocos.inserir.redirecionar",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de setores",
            'unico' => "N",
            'apelido' => "gruposusuarios",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Liberar acessos de setores",
            'unico' => "S",
            'apelido' => "gruposusuarios.acessos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de estado de chapas",
            'unico' => "N",
            'apelido' => "estados_chapas",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de espessuras de chapas",
            'unico' => "N",
            'apelido' => "espessuras_chapas",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de observações de chapas",
            'unico' => "N",
            'apelido' => "observacoes_chapas",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de chapas",
            'unico' => "N",
            'apelido' => "chapas",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de material de processo",
            'unico' => "N",
            'apelido' => "tipo_material_processos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de motivos de não conclusão de processos",
            'unico' => "N",
            'apelido' => "motivo_nao_conclusao_processos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de motivos utilizados em processos",
            'unico' => "N",
            'apelido' => "motivos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Processos",
            'unico' => "N",
            'apelido' => "processos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Agendamento de processos",
            'unico' => "N",
            'apelido' => "agendamento_processos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Executar processos",
            'unico' => "N",
            'apelido' => "executar_processos",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
        DB::table('acessos')->insert([
            'nome' => "Cadastro de chapas serradas",
            'unico' => "N",
            'apelido' => "chapas_serradas",
            'ativo' => "S",
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }
}
