@extends('layouts.containerfluid', ['activePage' => 'executar_processos', 'titlePage' => __($titleAux ?? 'Processos disponíveis')])
@section('containerfluid')
    @yield('padrao')
@endsection
