<?php

namespace App\Http\Controllers;

use App\BlocosBrutos;
use App\ChapasSerradas;
use App\ClassificacoesBlocos;
use App\Fornecedores;
use App\TiposBlocos;
use App\Transportadores;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RelatoriosController extends Controller
{
    public function estoqueChapasSerradas()
    {
        $this->temAcesso('relatorio_estoque_chapas_serradas');
        $data = request()->all();
        $chapas_serradas = ChapasSerradas::whereExists(function ($query) {
            $query->select(DB::raw(1))
                ->from('itens_chapas_serradas')
                ->whereColumn('itens_chapas_serradas.chapas_serradas_id', 'chapas_serradas.id')
                ->whereNull('chapas_bloco_id');
        });

        if (isset($data['numeracao']))
            $chapas_serradas->where('numeracao', 'like', '%' . $data['numeracao'] . '%');

        if (isset($data['tipos_blocos']))
            $chapas_serradas->where('tipos_blocos_id', $data['tipos_blocos']);

        if (isset($data['dtinicial']) and isset($data['dtfinal']))
            $chapas_serradas->whereBetween('created_at', [$data['dtinicial'], $data['dtfinal']]);

        return view('pages.relatorios.estoque-chapas-serradas', [
            'chapas_serradas' => $chapas_serradas->get(),
            'tipos_blocos' => TiposBlocos::all()
        ]);
    }

    public function blocosChapas()
    {
        $this->temAcesso('relatorio_blocos_chapas');
        $data = request()->all();
        $blocos = DB::table('blocos')
            ->select('blocos.numeracao', 'blocos.created_at', 'tipos_blocos.descricao as material', 'chapas_blocos.espessuras_chapas_id', 'espessuras_chapas.descricao as espessura', DB::raw('count(chapas_blocos.id) as qtdChapas'), DB::raw('sum(chapas_blocos.comprimento * chapas_blocos.largura) as m2'))
            ->join('chapas_blocos', 'blocos.id', '=', 'chapas_blocos.blocos_id')
            ->join('tipos_blocos', 'blocos.tipos_blocos_id', '=', 'tipos_blocos.id')
            ->join('espessuras_chapas', 'chapas_blocos.espessuras_chapas_id', '=', 'espessuras_chapas.id')
            ->groupBy('blocos.numeracao', 'blocos.created_at', 'tipos_blocos.descricao', 'chapas_blocos.espessuras_chapas_id', 'espessuras_chapas.descricao');

        if (isset($data['numeracao']))
            $blocos->where('blocos.numeracao', 'like', '%' . $data['numeracao'] . '%');

        if (isset($data['tipos_blocos']))
            $blocos->where('tipos_blocos.id', $data['tipos_blocos']);

        if (isset($data['dtinicial']) and isset($data['dtfinal']))
            $blocos->whereBetween('blocos.created_at', [$data['dtinicial'], $data['dtfinal'] . ' 23:59:59 999']);

        return view('pages.relatorios.blocos-chapas', [
            'blocos' => $blocos->get(),
            'tipos_blocos' => TiposBlocos::all()
        ]);
    }

    public function estoqueBlocos()
    {
        $this->temAcesso('relatorio_estoque_blocos');
        $data = request()->all();
        $blocos_brutos = BlocosBrutos::whereNull('chapas_serradas_id');

        if (isset($data['numeracao']))
            $blocos_brutos->where('numeracao', 'like', '%' . $data['numeracao'] . '%');

        if (isset($data['tipos_blocos']))
            $blocos_brutos->where('tipos_blocos_id', $data['tipos_blocos']);

        if (isset($data['transportadores_id']))
            $blocos_brutos->where('transportadores_id', $data['transportadores_id']);

        if (isset($data['fornecedores_id']))
            $blocos_brutos->where('fornecedores_id', $data['fornecedores_id']);

        if (isset($data['classificacoes_blocos_id']))
            $blocos_brutos->where('classificacoes_blocos_id', $data['classificacoes_blocos_id']);

        if (isset($data['dtinicial']) and isset($data['dtfinal']))
            $blocos_brutos->whereBetween('created_at', [$data['dtinicial'], $data['dtfinal']  . ' 23:59:59 999']);

        return view('pages.relatorios.estoque-blocos-brutos', [
            'blocos_brutos' => $blocos_brutos->get(),
            'tipos_blocos' => TiposBlocos::all(),
            'transportadores' => Transportadores::all(),
            'classificacoes_blocos' => ClassificacoesBlocos::all(),
            'fornecedores' => Fornecedores::all(),
        ]);
    }

}
