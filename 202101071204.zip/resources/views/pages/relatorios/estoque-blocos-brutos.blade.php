@extends('pages.relatorios.padrao', ['activePage' => 'relatorio_estoque_blocos_bruto', 'titlePage' => 'Estoque de blocos'])
@section('relatorio')
    <div class="card mt-2">
        <h4 class="card-header">Filtragem:</h4>
        <div class="card-body">
            <form>
                <div class="row">
                    <div class="col-3">
                        <label>Numeração do bloco</label>
                        <input class="form-control" placeholder="Numeração do bloco" name="numeracao"
                               value="{{ request()->get('numeracao') ?? null }}">
                    </div>
                    <div class="col-3">
                        <label>Material do bloco</label>
                        <select class="form-control select2" name="tipos_blocos">
                            <option value="">Todos...</option>
                            @foreach($tipos_blocos as $t)
                                <option value="{{ $t->id }}"
                                        @if((request()->get('tipos_blocos') ?? null) == $t->id ) selected @endif>{{ $t->descricao }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-3">
                        <label>Fornecedor</label>
                        <select class="form-control select2" name="fornecedores_id">
                            <option value="">Todos...</option>
                            @foreach($fornecedores as $f)
                                <option value="{{ $f->id }}"
                                        @if((request()->get('fornecedores_id') ?? null) == $f->id ) selected @endif>{{ $f->nome }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-3">
                        <label>Classificação</label>
                        <select class="form-control select2" name="classificacoes_blocos_id">
                            <option value="">Todos...</option>
                            @foreach($classificacoes_blocos as $c)
                                <option value="{{ $c->id }}"
                                        @if((request()->get('classificacoes_blocos_id') ?? null) == $c->id ) selected @endif>{{ $c->descricao }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-3">
                        <label>Transportador</label>
                        <select class="form-control select2" name="transportadores_id">
                            <option value="">Todos...</option>
                            @foreach($transportadores as $t)
                                <option value="{{ $t->id }}"
                                        @if((request()->get('transportadores_id') ?? null) == $t->id ) selected @endif>{{ $t->nome . ' - ' . $t->placa }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-3">
                        <label>Data inicial</label>
                        <input type="date" class="form-control" name="dtinicial"
                               value="{{ request()->get('dtinicial') ?? null }}">
                    </div>
                    <div class="col-3">
                        <label>Data final</label>
                        <input type="date" class="form-control" name="dtfinal"
                               value="{{ request()->get('dtfinal') ?? null }}">
                    </div>
                </div>
                <div class="row mt-2 ocultarNaImpressao">
                    <div class="col-2">
                        <button type="submit" class="btn btn-block btn-warning">Aplicar filtros</button>
                    </div>
                    <div class="col-1">
                        <button type="button" onclick="imprimir()" class="btn btn-block btn-primary">Imprimir</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    @if(!count($blocos_brutos))
        <div class="container">
            <div class="alert alert-danger mt-3">Nenhum bloco encontrado...</div>
        </div>
    @else
        <div style="border: 0;border-radius: 5px;padding: 5px;">
            <table class="table" border="1">
                <thead class=" text-warning">
                <tr>
                    <th>
                        Numeração do bloco
                    </th>
                    <th>
                        M³
                    </th>
                    <th>
                        Material do bloco
                    </th>
                    <th>
                        Fornecedor
                    </th>
                    <th>
                        Classificação
                    </th>
                    <th>
                        Transportador
                    </th>
                    <th class="text-center">
                        Cadastrado em
                    </th>
                </tr>
                </thead>
                <tbody>
                @php
                    $m3 = 0;
                @endphp
                @foreach($blocos_brutos as $b)
                    <tr>
                    @php
                    $m3Aux = $b->comprimento * $b->altura * $b->largura;
                    $m3 += $m3Aux;
                    @endphp
                        <td>
                            {{ $b->numeracao }}
                        </td>
                        <td>
                            {{ number_format($m3Aux, 2, ',', '.') }}
                        </td>
                        <td>
                            {{ $b->tiposBlocos()->first()->descricao }}
                        </td>
                        <td>
                            {{ $b->fornecedores()->first()->nome }}
                        </td>
                        <td>
                            {{ $b->classificacoes()->first()->descricao }}
                        </td>
                        <td>
                            {{ $b->transportadores()->first()->nome }}
                        </td>
                        <td class="text-center">
                            {{ date('d/m/Y', strtotime($b->created_at)) }}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            <div class="row">
                <div class="col-3">
                    <b>Quantidade total de blocos: {{ count($blocos_brutos) }}</b>
                </div>
                <div class="col-3">
                    <b>Total m³: {{ number_format($m3, 2, ',', '.') }}</b>
                </div>
            </div>
        </div>
    @endif
@endsection
