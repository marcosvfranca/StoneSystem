@extends('layouts.containerfluid', ['activePage' => 'blocos_brutos', 'titlePage' => __('Blocos')])
@section('containerfluid')
  @yield('padrao')
@endsection
