@extends('layouts.containerfluid', ['activePage' => 'ordem_de_serradas', 'titlePage' => __('Cadastro de ordem de serradas')])
@section('containerfluid')
  @yield('padrao')
@endsection
