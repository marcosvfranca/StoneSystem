<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EspessurasChapas extends Model
{
    protected $fillable = [
        'descricao'
    ];

    public function chapas()
    {
        return $this->hasMany(ChapasBlocos::class);
    }
}
