<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ChapasBlocosRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return auth()->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'comprimento' => 'required',
            'largura' => 'required',
            'numeracao' => 'required',
            'espessuras_chapas_id' => 'required',
            'qtd' => 'required'
        ];
    }

    public function messages()
    {
        return [
            'comprimento.required' => 'Preencha o comprimento',
            'largura.required' => 'Preencha a largura',
            'numeracao.required' => 'Preencha a numeração',
            'espessuras_chapas_id.required' => 'Selecione a espessura da chapa',
            'qtd.required' => 'Informe a quantidade'
        ];
    }
}
