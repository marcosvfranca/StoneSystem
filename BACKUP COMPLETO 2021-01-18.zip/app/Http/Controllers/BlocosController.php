<?php

namespace App\Http\Controllers;

use App\Blocos;
use App\EspessurasChapas;
use App\EstadosChapas;
use App\Http\Requests\BlocosRequest;
use App\ObservacoesChapas;
use App\TiposBlocos;
use App\Transportadores;

class BlocosController extends Controller
{

    public function rindex()
    {
        return redirect('blocos');
    }

    public function index()
    {
        $this->temAcesso('blocos');
        $blocos = Blocos::all();
        return view('pages.blocos.index', ['blocos' => $blocos]);
    }

    public function cadastrar()
    {
        $this->temAcesso('blocos', 'I');
        $data = [
            'transportadores' => Transportadores::all(),
            'tiposblocos' => TiposBlocos::all()
        ];
        return view('pages.blocos.cadastrar', ['data' => $data]);
    }

    public function editar($id)
    {
        return view('pages.blocos.alterar', [
            'bloco' => Blocos::findOrFail($id),
            'transportadores' => Transportadores::all(),
            'tiposblocos' => TiposBlocos::all(),
            'espessuras' => EspessurasChapas::all(),
            'estadosChapas' => EstadosChapas::all(),
            'observacoesChapas' => ObservacoesChapas::all(),
        ]);
    }

    public function deletar($id)
    {
        $b = Blocos::findOrFail($id);
        $b->deletar();
        return $this->rindex();
    }

    public function inserir(BlocosRequest $request)
    {
        $data = $request->all();
        $bloco = $this->create($data);
        if ($this->temAcesso('blocos.inserir.redirecionar'))
            return redirect()->route('blocos.editar', ['id' => $bloco->id]);
        else
            return $this->rindex();
    }

    public function alterar(BlocosRequest $request, $id)
    {
        $data = $request->all();
        $bloco = Blocos::findOrFail($id);
        $this->update($bloco, $data);
        return $this->rindex();
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Blocos
     */
    protected function create(array $data)
    {
        return Blocos::create($data);
    }
    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Blocos
     */
    protected function update($bloco, array $data)
    {
//        dd($data);
        return $bloco->update($data);
    }
}
