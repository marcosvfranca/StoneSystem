<?php $user = app('App\User'); ?>
<?php $__env->startSection('padrao'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-warning">
                    <h4 class="card-title ">Funcionários cadastrados</h4>
                </div>
                <div class="card-body">
                    <?php if($user->temAcessoUnico('profile.edit', 'C')): ?>
                        <div class="row">
                            <div class="col-12 text-right">
                                <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-warning">
                                    <i class="material-icons">group</i>
                                    <div class="ripple-container"></div>
                                    <?php echo e(__('Cadastrar funcionário')); ?></a>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-warning">
                            <tr>
                                <th>
                                    Nome
                                </th>
                                <th>
                                    Login
                                </th>
                                <th>
                                    Setor
                                </th>
                                <th>
                                    Criado em
                                </th>
                                <th class="text-right">
                                    &nbsp;
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = \App\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($user->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($user->username); ?>

                                    </td>
                                    <td>
                                        <?php echo e($user->grupoUsuario()->first()->nome); ?>

                                    </td>
                                    <td>
                                        <?php echo e(date('d/m/Y', strtotime($user->created_at))); ?>

                                    </td>
                                    <td class="td-actions text-right">
                                        <a rel="tooltip" class="btn btn-success"
                                           href="<?php echo e(route('user.edit', ['user' => $user->id])); ?>"
                                           data-original-title="<?php echo e(__('Alterar funcionário')); ?>" title="<?php echo e(__('Alterar funcionário')); ?>">
                                            <i class="material-icons">edit</i>
                                            <div class="ripple-container"></div>
                                            <?php echo e(__('Alterar funcionário')); ?>

                                        </a>
                                        <form method="POST"
                                              action="<?php echo e(route('user.destroy', ['user' => $user->id])); ?>"
                                              style="display: inline-block">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <div class="form-group">
                                                <button rel="tooltip" class="btn btn-danger" type="submit"
                                                   data-original-title="<?php echo e(__('Excluir funcionário')); ?>" title="<?php echo e(__('Excluir funcionário')); ?>"
                                                    onclick="return confirm('Tem certeza que deseja deletar este funcionário?')">
                                                    <i class="material-icons">delete</i>
                                                    <div class="ripple-container"></div>
                                                    <?php echo e(__('Excluir funcionário')); ?>

                                                </button>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/users/index.blade.php ENDPATH**/ ?>