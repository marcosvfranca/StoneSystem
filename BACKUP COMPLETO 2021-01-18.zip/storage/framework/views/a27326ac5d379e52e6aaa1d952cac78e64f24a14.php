<?php $user = app('App\User'); ?>
<?php $__env->startSection('padrao'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session('status') or session('error')): ?>
            <?php $__env->startPush('js'); ?>
                <script>
                    $.notify({
                        icon: "insights",
                        message: "<?php echo e(session('status') ?? session('error')); ?>"
                    },{
                        type: <?php if(session('status')): ?> 'success' <?php else: ?> 'danger' <?php endif; ?>,
                        withtimer: 500,
                        placement: {
                            from: 'top',
                            align: 'center'
                        }
                    });
                </script>
            <?php $__env->stopPush(); ?>
        <?php endif; ?>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Processos</h4>
            </div>
            <div class="card-body">
                <?php if($user->temAcessoUnico('processos', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('processos.create')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">insights</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Cadastrar processo')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($processos)): ?>
                        <span>Nenhum processo cadastrado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Processo
                            </th>
                            <th class="text-right" width="50">
                                Exige material
                            </th>
                            <th class="text-right" width="50">
                                Ultimo processo
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $processos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($p->nome); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($p->exige_material == 'S' ? 'Sim' : 'Não'); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($p->ultimo_processo == 'S' ? 'Sim' : 'Não'); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e(date('d/m/Y', strtotime($p->created_at))); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <?php if($user->temAcessoUnico('processos', 'A')): ?>
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('processos.edit', ['processo' => $p->id])); ?>"
                                       data-original-title="<?php echo e(__('Alterar processo')); ?>" title="<?php echo e(__('Alterar processo')); ?>">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Alterar processo')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->temAcessoUnico('processos', 'E')): ?>
                                        <form action="<?php echo e(route('processos.destroy', ['processo' => $p->id])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="<?php echo e(__('Excluir processo')); ?>" title="<?php echo e(__('Excluir processo')); ?>"
                                               onclick="return confirm('Deseja excluir este processo?')">
                                                <i class="material-icons">delete</i>
                                                <?php echo e(__('Excluir processo')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.processos.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/processos/index.blade.php ENDPATH**/ ?>