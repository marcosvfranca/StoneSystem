<?php $user = app('App\User'); ?>
<?php $__env->startSection('blocos'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Blocos cadastrados</h4>
            </div>
            <div class="card-body">
                <?php if($user->temAcessoUnico('blocos', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('blocos.cadastrar')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">view_agenda</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Cadastrar bloco')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($blocos)): ?>
                        <span>Nenhum bloco cadastrado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Numeração
                            </th>
                            <th class="text-center">
                                Transportador /
                                <br>
                                Placa
                            </th>
                            <th>
                                Classificação
                            </th>
                            <th class="text-center">
                                Quantidade de chapas
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $blocos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($b->numeracao); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($b->transportadores()->first()->nome ?? 'Sem transportador'); ?>

                                    <br>
                                    <?php echo e($b->transportadores()->first()->placa ?? 'Sem transportador'); ?>

                                </td>
                                <td>
                                    <?php echo e($b->tiposBlocos()->first()->descricao ?? 'Sem classificação de bloco'); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($b->chapas()->count()); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e(date('d/m/Y', strtotime($b->created_at))); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <?php if($user->temAcessoUnico('blocos', 'A')): ?>
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('blocos.editar', ['id' => $b->id])); ?>"
                                       data-original-title="<?php echo e(__('Cadastrar chapas')); ?>" title="<?php echo e(__('Cadastrar chapas')); ?>">
                                        <i class="material-icons">equalizer</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Gerenciar chapas')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->temAcessoUnico('blocos', 'E')): ?>
                                    <a rel="tooltip" class="btn btn-danger" href="<?php echo e(route('blocos.deletar', ['id' => $b->id])); ?>"
                                       data-original-title="<?php echo e(__('Excluir bloco')); ?>" title="<?php echo e(__('Excluir bloco')); ?>">
                                        <i class="material-icons">delete</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Excluir bloco')); ?>

                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.blocos.blocos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/blocos/index.blade.php ENDPATH**/ ?>