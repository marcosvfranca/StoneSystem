<?php $__env->startSection('padrao'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header card-header-warning">
                    <h4 class="card-title ">Gerenciar agendamento de processo</h4>
                </div>
                <div class="card-body">
                    <form
                        action="<?php echo e(route('agendamento-processos.update', ['agendamento_processo' => $agendamentoProcesso])); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="liberado" value="S">
                        <div class="row">
                            <div class="col-6 form-group">
                                <select class="form-control select2 <?php $__errorArgs = ['processo_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="processo_id">
                                    <option value="<?php echo e($agendamentoProcesso->processo_id); ?>"
                                            selected><?php echo e($agendamentoProcesso->processo()->first()->nome); ?></option>
                                </select>
                                <?php $__errorArgs = ['processo_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6 form-group">
                                <select class="form-control select2 <?php $__errorArgs = ['grupos_usuario_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="grupos_usuario_id">
                                    <option value="">Selecione o setor...</option>
                                    <?php $__currentLoopData = $gruposUsuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($g->id); ?>"
                                                <?php if($g->id == (old('grupos_usuario_id') ?? $agendamentoProcesso->grupos_usuario_id)): ?> selected <?php endif; ?>><?php echo e($g->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['grupos_usuario_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-8 form-group">
                                <textarea name="observacoes" placeholder="Observações"
                                          class="form-control <?php $__errorArgs = ['observacoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('observacoes') ?? $agendamentoProcesso->observacoes); ?></textarea>
                                <?php $__errorArgs = ['observacoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-4 form-group text-center">
                                <button type="submit"
                                        onclick="return confirm('Ao liberar o agendamento ele estará disponível para execução dos operadores, tem certeza?');"
                                        class="btn btn-warning"> Liberar agendamento
                                </button>
                            </div>
                        </div>
                    </form>
                    <div class="col-12 form-group" id="chapasCadastradas">
                        <?php echo $__env->make('pages.agendamentoprocessos.chapascadastradas', ['chapas' => $agendamentoProcesso->chapas()->get()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="row">
                        <div class="col-9">
                            <input type="search" placeholder="Digite aqui para pesquisar uma chapa..."
                                   class="form-control" name="pesquisa">
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-warning" id="btnCadastrarChapas"
                                    onclick="cadastraChapas()"
                                    data-original-text="Adicionar chapas selecionadas">Adicionar chapas selecionadas
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12" id="materiaisProcesso">
                            <?php echo $__env->make('pages.agendamentoprocessos.materiaisprocesso', ['processo' => $agendamentoProcesso->processo()->first()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-12">
                            <h4 class="font-weight-bold">Chapas disponíveis para agendamento</h4>
                        </div>
                        <div class="col-12" id="pesquisaDeChapas">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            <?php if(session('status') or session('error')): ?>
            $.notify({
                icon: "note_add",
                message: "<?php echo e(session('status') ?? session('error')); ?>"
            }, {
                type: <?php if(session('status')): ?> 'success' <?php else: ?> 'danger' <?php endif; ?>,
                withtimer: 500,
                placement: {
                    from: 'top',
                    align: 'center'
                }
            });
            <?php endif; ?>
            function loadPesquisaDeChapas() {
                var pesquisa = $('input[name="pesquisa"]').val();
                var get = "?id=<?php echo e($agendamentoProcesso->id); ?>";
                if (pesquisa)
                    get += "&q=" + pesquisa;
                $('#pesquisaDeChapas').load('<?php echo e(route('agendamento-processos.pesquisa-bloco')); ?>' + get);
            }

            function loadChapasAgendadas() {
                $('#chapasCadastradas').load('<?php echo e(route('chapas-agendamentos.index', ['agendamentoProcesso' => $agendamentoProcesso->id])); ?>');
            }

            loadPesquisaDeChapas();

            $(document).on('change', '.checkboxBloco', function () {
                var $this = $(this);
                var elements = 'input[type="checkbox"][data-bloco-id="' + $this.attr('data-id') + '"]';
                $(elements).prop('checked', $this.is(':checked'));
            });

            $('input[name="pesquisa"]').keyup(function () {
                loadPesquisaDeChapas();
            });

            function cadastraChapas() {
                var chapas = [];
                $('.checkboxChapa:checked').each(function () {
                    chapas.push($(this).attr('data-chapa-id'));
                });

                $.ajax({
                    method: 'POST',
                    url: '<?php echo e(route('chapas-agendamentos.store')); ?>',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        agendamento_processo_id: <?php echo e($agendamentoProcesso->id); ?>,
                        chapas_bloco: chapas,
                        tipos_materiais: $('select[name="tipoMaterialProcessos[]"]').val()
                    },
                    beforeSend: function () {
                        $('#btnCadastrarChapas').text('Aguarde...');
                    },
                    success: function (data) {
                        $.notify({
                            icon: "equalizer",
                            message: "Chapas cadastradas com sucesso"
                        }, {
                            type: 'success',
                            withtimer: 500,
                            placement: {
                                from: 'top',
                                align: 'center'
                            }
                        });
                        loadPesquisaDeChapas();
                        loadChapasAgendadas();
                    },
                    complete: function () {
                        var $btn = $('#btnCadastrarChapas');
                        $btn.html($btn.attr('data-original-text'));
                    },
                    error: function (e) {
                        console.log(e);
                        $.each(e.responseJSON.errors, function (key, value) {
                            $.notify({
                                icon: "error_outline",
                                message: value
                            }, {
                                type: 'danger',
                                withtimer: 500,
                                placement: {
                                    from: 'bottom',
                                    align: 'center'
                                }
                            });
                        });
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.agendamentoprocessos.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/agendamentoprocessos/edit.blade.php ENDPATH**/ ?>