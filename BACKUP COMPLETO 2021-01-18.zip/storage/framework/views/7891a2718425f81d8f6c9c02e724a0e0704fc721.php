<?php $__env->startPush('js'); ?>
<script>
$('#tipo_material_processos').select2({
    placeholder: 'Clique aqui para selecionar os materiais do processo'
})
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\StoneSystem\resources\views/pages/processos/js.blade.php ENDPATH**/ ?>