<?php $user = app('App\User'); ?>
<?php $__env->startSection('gruposusuarios'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Setores</h4>
            </div>
            <div class="card-body">
                <?php if($user->temAcessoUnico('gruposusuarios', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('gruposusuarios.cadastrar')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">groups</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Cadastrar setor')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($gruposusuarios)): ?>
                        <span>Nenhum setor cadastrado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Nome
                            </th>
                            <th class="text-center">
                                Administrador?
                            </th>
                            <th class="text-right">
                                Quantidade de funcionários
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $gruposusuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($g->nome); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($g->admin == 'S' ? 'Sim' : 'Não'); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($g->usuarios()->count()); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <?php if($user->temAcessoUnico('gruposusuarios', 'A')): ?>
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('gruposusuarios.editar', ['id' => $g->id])); ?>"
                                       data-original-title="<?php echo e(__('Gerênciar setor')); ?>" title="<?php echo e(__('Gerênciar setor')); ?>">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Gerênciar setor')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->temAcessoUnico('gruposusuarios', 'E')): ?>
                                    <a rel="tooltip" class="btn btn-danger" href="<?php echo e(route('gruposusuarios.deletar', ['id' => $g->id])); ?>"
                                       data-original-title="<?php echo e(__('Excluir setor')); ?>" title="<?php echo e(__('Excluir setor')); ?>"
                                       onclick="return confirm('Confirma a exclusão deste setor?');">
                                        <i class="material-icons">delete</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Excluir setor')); ?>

                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.gruposusuarios.gruposusuarios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/gruposusuarios/index.blade.php ENDPATH**/ ?>