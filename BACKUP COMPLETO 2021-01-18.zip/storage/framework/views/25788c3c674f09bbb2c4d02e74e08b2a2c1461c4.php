<?php if(!$agendamento->chapas()->whereNull('concluido')->where('cancelado', 'N')->count()): ?>
<div class="alert alert-success">
    <h4 class="font-weight-bold text-uppercase"><?php echo e($agendamento->processo()->first()->nome); ?> concluido. Clique no botão abaixo para finalizar.</h4>
    <a href="<?php echo e(route('executar-processos.index')); ?>" class="btn btn-warning text-uppercase">finalizar <?php echo e($agendamento->processo()->first()->nome); ?></a>
</div>
<?php endif; ?>
<div class="table-responsive">
    <table class="table" border="1">
        <thead>
        <tr>
            <th width="10"><input type="checkbox" class="selectAll"></th>
            <th class="font-weight-bold">Numeração</th>
            <th class="font-weight-bold">Espessura</th>
            <th class="font-weight-bold">Comprimento</th>
            <th class="font-weight-bold">Largura</th>
            <th class="font-weight-bold text-danger">Materiais</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $agendamento->chapas()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="
                                                <?php if($c->concluido == 'S'): ?> font-weight-bold bg-success <?php endif; ?>
            <?php if($c->cancelado == 'S'): ?> font-weight-bold bg-danger <?php endif; ?>
            <?php if($c->concluido == 'N'): ?> font-weight-bold bg-warning <?php endif; ?>
                ">
                <th><input type="checkbox" class="checkChapas" data-id="<?php echo e($c->id); ?>"
                           <?php if(in_array($c->concluido == 'S', ['S', 'N']) or $c->motivo_cancelamento_id or $c->motivo_nao_conclusao_processo_id): ?> disabled <?php endif; ?>
                    ></th>
                <td class="font-weight-bold"><?php echo e($c->chapa()->numeracao); ?></td>
                <td><?php echo e($c->chapa()->espessura()->first()->descricao); ?></td>
                <td><?php echo e($c->chapa()->comprimento); ?></td>
                <td><?php echo e($c->chapa()->largura); ?></td>
                <td>
                    <ol>
                        <?php $__currentLoopData = $c->tiposMateriais()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoMaterial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($tipoMaterial->tipo); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\StoneSystem\resources\views/pages/agendamentoprocessos/executar/chapas.blade.php ENDPATH**/ ?>