<?php $user = app('App\User'); ?>
<?php $__env->startSection('padrao'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session('status') or session('error')): ?>
            <?php $__env->startPush('js'); ?>
                <script>
                    $.notify({
                        icon: "cancel_presentation",
                        message: "<?php echo e(session('status') ?? session('error')); ?>"
                    },{
                        type: <?php if(session('status')): ?> 'success' <?php else: ?> 'danger' <?php endif; ?>,
                        withtimer: 500,
                        placement: {
                            from: 'top',
                            align: 'center'
                        }
                    });
                </script>
            <?php $__env->stopPush(); ?>
        <?php endif; ?>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Motivos de cancelamento de processos</h4>
            </div>
            <div class="card-body">
                <?php if($user->temAcessoUnico('motivo_cancelamentos', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('motivo-cancelamentos.create')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">cancel_presentation</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Cadastrar motivo de cancelamento de processo')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($otivos)): ?>
                        <span>Nenhum motivo de cancelamento de processo cadastrado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Motivo
                            </th>
                            <th class="text-right" width="200">
                                Presente em (Processos)
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $motivoCancelamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($m->motivo); ?>

                                </td>
                                <td class="text-right">
                                    corrigir

                                </td>
                                <td class="text-center">
                                    <?php echo e(date('d/m/Y', strtotime($m->created_at))); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <?php if($user->temAcessoUnico('motivo_cancelamentos', 'A')): ?>
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('motivo-cancelamentos.edit', ['motivo_cancelamento' => $m->id])); ?>"
                                       data-original-title="<?php echo e(__('Alterar motivo')); ?>" title="<?php echo e(__('Alterar motivo')); ?>">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Alterar motivo')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->temAcessoUnico('motivo_cancelamentos', 'E')): ?>
                                        <form action="<?php echo e(route('motivo-cancelamentos.destroy', ['motivo_cancelamento' => $m->id])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="<?php echo e(__('Excluir motivo')); ?>" title="<?php echo e(__('Excluir motivo')); ?>"
                                               onclick="return confirm('Deseja excluir esse motivo de cancelamento de processo?')">
                                                <i class="material-icons">delete</i>
                                                <?php echo e(__('Excluir motivo')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.motivocancelamentos.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/motivocancelamentos/index.blade.php ENDPATH**/ ?>
