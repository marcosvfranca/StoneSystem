<?php $__env->startSection('containerfluid'); ?>
    <?php echo $__env->yieldContent('padrao'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.containerfluid', ['activePage' => 'user-management', 'titlePage' => __('Cadastro de funcionários')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/users/padrao.blade.php ENDPATH**/ ?>