<?php $user = app('App\User'); ?>
<?php $__env->startSection('padrao'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(session('status') or session('error')): ?>
            <?php $__env->startPush('js'); ?>
                <script>
                    $.notify({
                        icon: "library_books",
                        message: "<?php echo e(session('status') ?? session('error')); ?>"
                    },{
                        type: <?php if(session('status')): ?> 'success' <?php else: ?> 'danger' <?php endif; ?>,
                        timer: 500,
                        placement: {
                            from: 'top',
                            align: 'center'
                        }
                    });
                </script>
            <?php $__env->stopPush(); ?>
        <?php endif; ?>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Material de processos</h4>
            </div>
            <div class="card-body">
                <?php if($user->temAcessoUnico('tipo_material_processos', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('tipo-material-processos.create')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">library_books</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Cadastrar material de processo')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($tipoMaterialProcessos)): ?>
                        <span>Nenhuma material de processo cadastrado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Material
                            </th>
                            <th class="text-right" width="100">
                                Presente em (Chapas)
                            </th>
                            <th class="text-right" width="100">
                                Presente em (Processos)
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tipoMaterialProcessos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($t->tipo); ?>

                                </td>
                                <td class="text-right">
                                    00000

                                </td>
                                <td class="text-right">
                                    corrigir

                                </td>
                                <td class="text-center">
                                    <?php echo e(date('d/m/Y', strtotime($t->created_at))); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <?php if($user->temAcessoUnico('tipo_material_processos', 'A')): ?>
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('tipo-material-processos.edit', ['tipo_material_processo' => $t->id])); ?>"
                                       data-original-title="<?php echo e(__('Alterar material de processo')); ?>" title="<?php echo e(__('Alterar material de processo')); ?>">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Alterar material de processo')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->temAcessoUnico('tipo_material_processos', 'E')): ?>
                                        <form action="<?php echo e(route('tipo-material-processos.destroy', ['tipo_material_processo' => $t->id])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="<?php echo e(__('Excluir material de processo')); ?>" title="<?php echo e(__('Excluir material de processo')); ?>"
                                               onclick="return confirm('Deseja excluir esse material de processo?')">
                                                <i class="material-icons">delete</i>
                                                <?php echo e(__('Excluir material de processo')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.tipomaterialprocessos.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/tipomaterialprocessos/index.blade.php ENDPATH**/ ?>