<form method="post" action="<?php echo e(route('chapas.store')); ?>" class="formCreateChapa" data-message="Chapa cadastrada com sucesso">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="blocos_id" value="<?php echo e($bloco->id); ?>">
    <div class="row">
        <div class="col-2 form-group text-left">
            <label>Nº de chapas</label>
        </div>
        <div class="col-2 form-group">
            <input type="number" value="<?php echo e(old('qtd') ?? 1); ?>" name="qtd" class="form-control <?php $__errorArgs = ['qtd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Quantidade">
            <span class="error text-danger"></span>
        </div>
        <div class="col-3 form-group">
            <input type="text" name="numeracao" value="<?php echo e(old('numeracao')); ?>" placeholder="Numeração" class="form-control">
            <span class="error text-danger"></span>
        </div>
        <div class="col-2 form-group">
            <input type="text" name="comprimento" value="<?php echo e(old('comprimento')); ?>" placeholder="Comprimento" class="form-control">
            <span class="error text-danger"></span>
        </div>
        <div class="col-2 form-group">
            <input type="text" name="largura" value="<?php echo e(old('largura')); ?>" placeholder="Largura" class="form-control">
            <span class="error text-danger"></span>
        </div>
        <div class="col-6 form-group">
            <select name="espessuras_chapas_id" class="select2 w-100 select2EspessuraChapa">
                <option value="">Selecione a espessura da chapa</option>
                <?php $__currentLoopData = $espessuras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->id); ?>" <?php if($e->id == old('espessuras_chapas_id')): ?> selected <?php endif; ?>><?php echo e($e->descricao); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <span class="error text-danger"></span>
        </div>
        <div class="col-6 form-group">
            <select class="w-100 select2EstadosChapa" name="estadosChapa[]" multiple="multiple">
                <?php $__currentLoopData = $estadosChapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->descricao); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php $__env->startPush('js'); ?>
                <script>$('.select2EstadosChapa').select2({placeholder: 'Selecione o estado da chapa'});</script>
            <?php $__env->stopPush(); ?>
        </div>
        <div class="col-6 form-group">
            <select class="w-100 select2ObservacoesChapa" name="observacoesChapa[]" multiple="multiple">
                <?php $__currentLoopData = $observacoesChapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($o->id); ?>"><?php echo e($o->apelido); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php $__env->startPush('js'); ?>
                <script>$('.select2ObservacoesChapa').select2({placeholder: 'Selecione as observações da chapa'});</script>
            <?php $__env->stopPush(); ?>
        </div>
        <div class="col-12 text-center form-group">
            <button class="btn btn-warning" type="submit" data-original-text="Cadastrar chapa">Cadastrar chapas</button>
        </div>
    </div>
</form>
<?php /**PATH C:\StoneSystem\resources\views/pages/blocos/chapas/create.blade.php ENDPATH**/ ?>