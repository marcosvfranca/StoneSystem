<?php $user = app('App\User'); ?>
<?php $__env->startSection('gruposusuarios'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-warning">
                    <h4 class="card-title ">Alterar setor</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('gruposusuarios.alterar', ['id' => $gruposusuarios->id])); ?>"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-3 form-group">
                                <input class="form-control <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nome"
                                       placeholder="Nome" value="<?php echo e($gruposusuarios->nome); ?>">
                                <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error text-danger"><?php echo e($errors->first('nome')); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-4 form-group">
                                <label style="font-size: 16px;">É administrador? </label>
                                <div class="form-check form-check-radio form-check-inline ml-2">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="radio" name="admin" id="admin1" value="S"
                                               <?php if($gruposusuarios->admin == 'S'): ?> checked <?php endif; ?> autofocus>
                                        Sim
                                        <span class="circle">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                                <div class="form-check form-check-radio form-check-inline">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="radio" name="admin" id="admin2" value="N"
                                               <?php if($gruposusuarios->admin == 'N'): ?> checked <?php endif; ?>>
                                        Não
                                        <span class="circle">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-2 form-group">
                                <button type="submit" class="btn btn btn-warning"> Alterar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php if($gruposusuarios->admin != 'S' and $user->temAcessoUnico('gruposusuarios.acessos')): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-warning">
                    <h4 class="card-title ">Configurar acessos do setor: <?php echo e($gruposusuarios->nome); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-warning">
                                    <h4 class="card-title ">Acessos disponíveis para o setor</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-6 form-group">
                                            <input type="search" placeholder="Pesquisar acesso" id="searchAcessos" class="form-control" onkeyup="search(this)" data-table="tableSearchAcessos">
                                        </div>
                                    </div>
                                    <div class="table-responsive" id="acessos" style="max-height:300px;overflow-y:auto;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-warning">
                                    <h4 class="card-title ">Acessos que o setor possuí</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-6 form-group">
                                            <input type="search" placeholder="Pesquisar acesso" id="searchAcessosGruposUsuarios" class="form-control" onkeyup="search(this)" data-table="tableSearchAcessosGruposUsuarios">
                                        </div>
                                    </div>
                                    <div class="table-responsive" id="acessosGruposUsuarios"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            loadAll();
            $(document).on('change', '.checkAcesso', function () {
                var check = $(this);
                $('#btnLiberaAcesso' + check.attr('data-value')).attr('data-' + check.attr('data-name'), (check.is(':checked') ? 'S' : 'N'));
            });
            $(document).on('click', 'button.liberaAcesso', function () {
                var btn = $(this);
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(route('gruposusuarios.liberaracesso')); ?>',
                    dataType: 'text',
                    data: {
                        'inserir': btn.attr('data-inserir'),
                        'alterar': btn.attr('data-alterar'),
                        'excluir': btn.attr('data-excluir'),
                        'id-acesso': btn.attr('data-id-acesso'),
                        'id-grupo': btn.attr('data-id-grupo'),
                        '_token': btn.attr('data-csfr')
                    },
                    // beforeSend: function () {
                    //     carregando();
                    // },
                    success: function (r) {
                        loadAll();
                    },
                    // complete: function () {
                    //     carregando('hide');
                    // },
                    error: function (e) {
                        console.log(e);
                        alert('Houve um erro ao liberar o acesso, tente novamente');
                    }
                });
            });
            $(document).on('click', 'button.removeAcesso', function () {
                var btn = $(this);
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(route('gruposusuarios.removeacesso')); ?>',
                    dataType: 'text',
                    data: {
                        'id': btn.attr('data-id'),
                        '_token': btn.attr('data-csfr')
                    },
                    // beforeSend: function () {
                    //     carregando();
                    // },
                    success: function (r) {
                        loadAll();
                    },
                    // complete: function () {
                    //     carregando('hide');
                    // },
                    error: function (e) {
                        console.log(e);
                        alert('Houve um erro ao remover o acesso, tente novamente');
                        location.reload();
                    }
                });
            });
            function loadAll() {
                $('#acessos').load('<?php echo e(route('gruposusuarios.acessos', ['id' => $gruposusuarios->id])); ?>', function () {
                    search(document.getElementById('searchAcessos'));
                });
                $('#acessosGruposUsuarios').load('<?php echo e(route('gruposusuarios.acessosgruposusuarios', ['id' => $gruposusuarios->id])); ?>', function () {
                    search(document.getElementById('searchAcessosGruposUsuarios'));
                });
            }

            function search(este) {
                    var value = este.value.toLowerCase().trim();
                    if (!value)
                        return;
                    $("table." + este.getAttribute('data-table') + " tr").each(function (index) {
                        if (!index) return;
                        $(this).find("td").each(function () {
                            var id = $(this).text().toLowerCase().trim();
                            var not_found = (id.indexOf(value) == -1);
                            $(this).closest('tr').toggle(!not_found);
                            return not_found;
                        });
                    });
            }

        </script>
    <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.gruposusuarios.gruposusuarios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/gruposusuarios/alterar.blade.php ENDPATH**/ ?>