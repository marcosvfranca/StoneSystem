<?php $__env->startSection('containerfluid'); ?>
  <?php echo $__env->yieldContent('estados_chapas'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.containerfluid', ['activePage' => 'estados_chapas', 'titlePage' => __('Estados das chapas')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/estadoschapas/estadoschapas.blade.php ENDPATH**/ ?>