<?php $__env->startSection('padrao'); ?>
    <div class="row">
        <?php if($processosDisponiveis->count()): ?>
        <?php $__currentLoopData = $processosDisponiveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <div class="card">
                <div class="card-header card-header-warning">
                    <h4 class="card-title text-capitalize"><?php echo e($p->processo()->first()->nome); ?></h4>
                </div>
                <div class="card-body">
                    <h5><b>Quantidade de chapas:</b> <?php echo e($p->chapas()->count()); ?></h5>
                    <div style="display: flex"><h6>Observações: </h6><span style="margin-left: 5px;margin-top: -4px;"><?php echo e($p->observacoes ?? 'Sem observações'); ?></span></div>
                    <a class="btn btn-warning btn-block text-white" href="<?php echo e(route('executar-processos.edit', ['agendamento' => $p])); ?>">Realizar <?php echo e($p->processo()->first()->nome); ?></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-danger">Nada disponível...</div>
            </div>
        <?php endif; ?>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            setTimeout(function () {
                location.reload();
            }, 60000 * 5.1);
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.agendamentoprocessos.executar.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/agendamentoprocessos/executar/index.blade.php ENDPATH**/ ?>