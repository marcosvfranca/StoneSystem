<?php $__env->startSection('padrao'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Processos agendados</h4>
            </div>
            <div class="card-body">
                <?php if(auth()->user()->temAcessoUnico('agendamento_processos', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('agendamento-processos.create')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">note_add</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Agendar processo')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($agendamentoProcessos)): ?>
                        <span>Nenhum processo agendado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Setor
                            </th>
                            <th class="text-right" width="200">
                                Nome
                            </th>
                            <th class="text-center">
                                Observações
                            </th>
                            <th class="text-center">
                                Qtd Chapas
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $agendamentoProcessos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($a->grupoUsuario()->first()->nome); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($a->processo()->first()->nome); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($a->observacoes); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($a->chapas()->count()); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e(date('d/m/Y', strtotime($a->created_at))); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <?php if(auth()->user()->temAcessoUnico('agendamento_processos', 'A')): ?>
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('agendamento-processos.edit', ['agendamento_processo' => $a->id])); ?>"
                                       data-original-title="<?php echo e(__('Gerênciar agendamento')); ?>" title="<?php echo e(__('Gerênciar agendamento')); ?>">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Gerênciar agendamento')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->temAcessoUnico('agendamento_processos', 'E')): ?>
                                        <form action="<?php echo e(route('agendamento-processos.destroy', ['agendamento_processo' => $a->id])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="<?php echo e(__('Excluir agendamento')); ?>" title="<?php echo e(__('Excluir agendamento')); ?>"
                                               onclick="return confirm('Deseja excluir este agendamento?')">
                                                <i class="material-icons">delete</i>
                                                <?php echo e(__('Excluir agendamento')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.agendamentoprocessos.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/agendamentoprocessos/index.blade.php ENDPATH**/ ?>