<?php $__env->startSection('containerfluid'); ?>
  <?php echo $__env->yieldContent('padrao'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.containerfluid', [
    'activePage' => 'processos',
    'titlePage' => __('Processos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/processos/padrao.blade.php ENDPATH**/ ?>