<?php $user = app('App\User'); ?>
<?php $__env->startSection('padrao'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Estados de chapas cadastrados</h4>
            </div>
            <div class="card-body">
                <?php if($user->temAcessoUnico('estados_chapas', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('estados-chapas.create')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">calendar_view_day</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Cadastrar estado de chapa')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($estadosChapas)): ?>
                        <span>Nenhum estado de chapa cadastrado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Estado
                            </th>
                            <th class="text-right" width="200">
                                Presente em (Chapas)
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $estadosChapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($e->descricao); ?>

                                </td>
                                <td class="text-right" width="200">
                                    <?php echo e($e->chapas()->count()); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e(date('d/m/Y', strtotime($e->created_at))); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <?php if($user->temAcessoUnico('estados-chapas', 'A')): ?>
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('estados-chapas.edit', ['estados_chapa' => $e->id])); ?>"
                                       data-original-title="<?php echo e(__('Alterar estado de chapa')); ?>" title="<?php echo e(__('Alterar estado de chapa')); ?>">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Alterar estado de chapa')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->temAcessoUnico('estados-chapas', 'E')): ?>
                                        <form action="<?php echo e(route('estados-chapas.destroy', ['estados_chapa' => $e->id])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="<?php echo e(__('Excluir estado de chapa')); ?>" title="<?php echo e(__('Excluir estado de chapa')); ?>"
                                               onclick="return confirm('<?php echo e(__('Deseja excluir esse estado de chapa?')); ?>')">
                                                <i class="material-icons">delete</i>
                                                <?php echo e(__('Excluir estado de chapa')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.estadoschapas.padrao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/estadoschapas/index.blade.php ENDPATH**/ ?>