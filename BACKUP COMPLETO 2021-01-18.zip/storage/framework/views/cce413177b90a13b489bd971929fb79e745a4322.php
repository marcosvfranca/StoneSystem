<?php $__env->startSection('containerfluid'); ?>
  <?php echo $__env->yieldContent('padrao'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.containerfluid', ['activePage' => 'motivo_nao_conclusao_processos', 'titlePage' => __('Motivo não conclusão processos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/motivonaoconclusaoprocessos/padrao.blade.php ENDPATH**/ ?>