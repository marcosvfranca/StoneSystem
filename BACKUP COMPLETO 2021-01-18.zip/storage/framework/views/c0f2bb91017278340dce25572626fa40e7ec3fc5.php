<?php if($processo->tipoMaterialProcessos()->count()): ?>
<label>Selecione abaixo os materiais do processo</label>
<select name="tipoMaterialProcessos[]" multiple class="select2 w-100" data-placeholder="Clique aqui para selecionar os materiais do processo">
    <?php $__currentLoopData = $processo->tipoMaterialProcessos()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($t->id); ?>"><?php echo e($t->tipo); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php else: ?>
<div class="alert alert-danger"> Nenhum material disponível neste processo.
    <?php if(auth()->user()->temAcessoUnico('processos')): ?><p>Clique <a href="<?php echo e(route('processos.edit', ['processo' => $processo])); ?>">aqui</a> para adicionar materiais ao processo: <?php echo e($processo->nome); ?></p><?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH C:\StoneSystem\resources\views/pages/agendamentoprocessos/materiaisprocesso.blade.php ENDPATH**/ ?>