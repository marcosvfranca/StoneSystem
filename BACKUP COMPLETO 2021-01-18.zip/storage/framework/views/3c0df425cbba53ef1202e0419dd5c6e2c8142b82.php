<?php $__env->startSection('blocos'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title "><?php echo e(__('Gerenciar chapas. Bloco nº: ') . $bloco->numeracao); ?></h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('blocos.alterar', ['id' => $bloco->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-3 form-group">
                            <label class="ml-3 mt-3" for="numeracao">Numeração</label>
                            <input class="form-control mt-3 <?php $__errorArgs = ['numeracao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="numeracao" id="numeracao" placeholder="Numeração" value="<?php echo e($bloco->numeracao); ?>">
                            <?php $__errorArgs = ['numeracao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error text-danger"><?php echo e($errors->first('numeracao')); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="transportadores_id">Transportador / Placa</label>
                            <select class="form-control select2 <?php $__errorArgs = ['transportador_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="transportadores_id" id="transportadores_id">
                                <?php $__currentLoopData = $transportadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($t->id); ?>" <?php if($t->id == $bloco->transportadores_id): ?> selected <?php endif; ?>><?php echo e($t->nome); ?> / <?php echo e($t->placa); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['transportadores_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error text-danger"><?php echo e($errors->first('transportadores_id')); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="tipos_blocos_id">Classificação do bloco</label>
                            <select class="form-control select2 <?php $__errorArgs = ['tipos_blocos_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipos_blocos_id" id="tipos_blocos_id">
                                <?php $__currentLoopData = $tiposblocos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($t->id); ?>" <?php if($t->id == $bloco->tipos_blocos_id): ?> selected <?php endif; ?>><?php echo e($t->descricao); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['tipos_blocos_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error text-danger"><?php echo e($errors->first('tipos_blocos_id')); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-3 form-group">
                            <button type="submit" class="btn btn-warning"> Salvar dados do bloco</button>
                        </div>
                    </div>
                </form>
                <div class="row">
                    <div class="col-12">
                        <h3>Cadastrar chapas</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12" id="cadastroChapa">
                        <?php echo $__env->make('pages.blocos.chapas.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-12">
                        <h3 class="text-center">Chapas do bloco</h3>
                    </div>
                    <div class="col-12" id="tableChapas"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>function loadChapas(){$('#tableChapas').load('<?php echo e(route('chapas.index')); ?>?bloco=<?php echo e($bloco->id); ?>');}loadChapas();
    function loadCadastroChapa()
    {
        $.get('<?php echo e(route('chapas.createform', ['bloco' => $bloco->id])); ?>')
            .then(function (e) {
                $('#cadastroChapa').html(e);
                loadSelect2();
            });
    }
    function loadSelect2()
    {
        $('.select2EspessuraChapa').select2();
        $('.select2ObservacoesChapa').select2({placeholder: 'Selecione as observações da chapa'});
        $('.select2EstadosChapa').select2({placeholder: 'Selecione o estado da chapa'});
        $('input[name="numeracao"]').mask('000000000000000000000', {selectOnFocus: true});
    }

    function loadAll() {
        loadCadastroChapa();
        loadChapas();
    }
    $(document).on('submit', '.formCreateChapa, .formDeleteChapa', function (e) {
        e.preventDefault();
        $form = $(this);
        formData = $form.serializeArray();
        $.ajax({
            method: $form.attr('method'),
            url: $form.attr('action'),
            data: formData,
            beforeSend: function () {
                $form.find('button[type="submit"]').text('Carregando...');
            },
            success: function (data) {
                $.notify({
                    icon: "equalizer",
                    message: $form.attr('data-message')
                },{
                    type: 'success',
                    withtimer: 500,
                    placement: {
                        from: 'top',
                        align: 'center'
                    }
                });
                loadAll();
            },
            complete: function() {
                var $btn = $form.find('button[type="submit"]');
                $btn.html($btn.attr('data-original-text'));
            },
            error: function(e) {
                console.log(e);
                $form.find('span.error').html('');
                $.each(e.responseJSON.errors, function(key,value) {
                    $form.find('[name="' + key + '"]').parent().find('span.error').html(value);
                });
                if ($form.attr('data-message-error'))
                    $.notify({
                        icon: "equalizer",
                        message: $form.attr('data-message-error')
                    },{
                        type: 'error',
                        withtimer: 500,
                        placement: {
                            from: 'bottom',
                            align: 'center'
                        }
                    });
            }
        });
        return false;
    });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.blocos.blocos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/blocos/alterar.blade.php ENDPATH**/ ?>