<?php $user = app('App\User'); ?>
<?php if($chapas->count()): ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th class="text-center">
                        Numeração /
                        <br>
                        Estados
                    </th>
                    <th>
                        Observações
                    </th>
                    <th>
                        Espessura
                    </th>
                    <th>
                        Largura
                    </th>
                    <th>
                        Comprimento
                    </th>
                    <?php if($user->temAcessoUnico('chapas', 'A') or $user->temAcessoUnico('chapas', 'E')): ?>
                    <th></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $chapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div class="col-12">
                        <?php echo e($c->numeracao); ?>

                    </div>
                    <?php if($c->estados()->count()): ?>
                    <div class="col-12">
                        <ul>
                            <?php $__currentLoopData = $c->estados()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($e->descricao); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($c->observacoes()->count()): ?>
                    <ul>
                        <?php $__currentLoopData = $c->observacoes()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($o->apelido); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($c->espessura()->first()->descricao); ?>

                </td>
                <td>
                    <?php echo e($c->comprimento); ?>

                </td>
                <td>
                    <?php echo e($c->largura); ?>

                </td>
                <?php if($user->temAcessoUnico('chapas', 'A') or $user->temAcessoUnico('chapas', 'E')): ?>
                <td class="td-actions text-right">
                <?php if($user->temAcessoUnico('chapas', 'A')): ?>
                    <a rel="tooltip" class="btn btn-success"
                       href="<?php echo e(route('chapas.edit', ['chapa' => $c->id])); ?>"
                       data-original-title="<?php echo e(__('Alterar chapa')); ?>" title="<?php echo e(__('Alterar chapa')); ?>">
                        <i class="material-icons">edit</i>
                        <div class="ripple-container"></div>
                        <?php echo e(__('Alterar chapa')); ?>

                    </a>
                <?php endif; ?>
                <?php if($user->temAcessoUnico('chapas', 'E')): ?>
                    <form method="POST"
                          action="<?php echo e(route('chapas.destroy', ['chapa' => $c->id])); ?>"
                          style="display: inline-block">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <div class="form-group">
                            <button rel="tooltip" class="btn btn-danger" type="submit"
                                    data-original-title="<?php echo e(__('Excluir chapa')); ?>" title="<?php echo e(__('Excluir chapa')); ?>"
                                    onclick="return confirm('Tem certeza que deseja excluir a chapa de numeração: <?php echo e($c->numeracao); ?>?')">
                                <i class="material-icons">delete</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Excluir chapa')); ?>

                            </button>
                        </div>
                    </form>
                <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php else: ?>
    <div class="alert alert-info">Nenhuma chapa encontrada</div>
<?php endif; ?>
<?php /**PATH C:\StoneSystem\resources\views/pages/blocos/chapas.blade.php ENDPATH**/ ?>