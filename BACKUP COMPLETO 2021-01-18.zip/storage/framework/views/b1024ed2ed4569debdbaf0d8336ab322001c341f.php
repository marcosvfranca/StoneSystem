<?php if(count($chapas)): ?>
<h5 class="font-weight-bold">Chapas do agendamento</h5>
<div class="row">
    <?php $__currentLoopData = $chapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-3">
        <div class="card mt-1 mb-1">
            <div class="card-body">
                <div><h6><span class="font-weight-bold">Chapa nº:</span> <?php echo e($c->chapa()->numeracao); ?></h6></div>
                <div><span class="font-weight-bold">Espessura:</span> <?php echo e($c->chapa()->espessura()->first()->descricao); ?></div>
                <div><span class="font-weight-bold">Comprimento:</span> <?php echo e($c->chapa()->comprimento); ?></div>
                <div><span class="font-weight-bold">Largura:</span> <?php echo e($c->chapa()->largura); ?></div>
                <div>
                    <span class="font-weight-bold">Materiais:</span>
                    <ul>
                        <?php $__currentLoopData = $c->tiposMateriais()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoMaterial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($tipoMaterial->tipo); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php if(auth()->user()->temAcessoUnico('agendamento_processos', 'E')): ?>
                <form action="<?php echo e(route('chapas-agendamentos.destroy', ['chapas_agendamento' => $c])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-warning btn-sm btn-block">Remover chapa</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
    <div class="alert alert-danger"> Nenhuma chapa agendada neste processo, selecione-as abaixo.</div>
<?php endif; ?>
<?php /**PATH C:\StoneSystem\resources\views/pages/agendamentoprocessos/chapascadastradas.blade.php ENDPATH**/ ?>