<?php $__env->startSection('containerfluid'); ?>
  <?php echo $__env->yieldContent('transportadores'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.containerfluid', ['activePage' => 'transportadores', 'titlePage' => __('Transportadores')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/transportadores/tiposblocos.blade.php ENDPATH**/ ?>
