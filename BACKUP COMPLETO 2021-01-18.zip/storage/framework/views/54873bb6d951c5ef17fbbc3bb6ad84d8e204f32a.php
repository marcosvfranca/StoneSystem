<?php $__env->startSection('containerfluid'); ?>
  <?php echo $__env->yieldContent('padrao'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.containerfluid', ['activePage' => 'espessuras_chapas', 'titlePage' => __('Espessuras das chapas')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/espessuraschapas/padrao.blade.php ENDPATH**/ ?>