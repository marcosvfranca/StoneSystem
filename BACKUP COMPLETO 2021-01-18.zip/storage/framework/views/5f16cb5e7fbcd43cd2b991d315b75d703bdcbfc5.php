<?php if(count($blocos)): ?>
<div class="table-responsive">
    <table class="table">
        <tbody>
        <?php $__currentLoopData = $blocos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bloco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-light">
                <th>
                    <input type="checkbox" class="checkbox checkboxBloco" data-id="<?php echo e($bloco->id); ?>">
                </th>
                <th>
                    Bloco nº: <?php echo e($bloco->numeracao); ?>

                </th>
                <th>
                    Categoria: <?php echo e($bloco->tiposBlocos()->first()->descricao); ?>

                </th>
                <th>
                    Transportador: <?php echo e($bloco->transportadores()->first()->nome); ?> - <?php echo e($bloco->transportadores()->first()->placa); ?>

                </th>
                <th>
                    &nbsp;
                </th>
            </tr>
            <?php $__currentLoopData = $bloco->chapas()
                        ->whereNotExists(function ($q) {
                            $q
                            ->select(\Illuminate\Support\Facades\DB::raw(1))
                            ->from('chapa_bloco_agendamento_processos')
                            ->whereRaw('chapa_bloco_agendamento_processos.chapas_bloco_id = chapas_blocos.id')
                            ;
                        })
                        ->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <input type="checkbox" class="checkbox checkboxChapa" data-chapa-id="<?php echo e($chapa->id); ?>" data-bloco-id="<?php echo e($bloco->id); ?>">
                    </td>
                    <td>
                        Chapa nº: <?php echo e($chapa->numeracao); ?>

                    </td>
                    <td>
                        Espessura: <?php echo e($chapa->espessura()->first()->descricao); ?>

                    </td>
                    <td>
                        Comprimento: <?php echo e($chapa->comprimento); ?>

                    </td>
                    <td>
                        Largura: <?php echo e($chapa->largura); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php else: ?>
    <div class="alert alert-danger">
        Nada encontrado...
    </div>
<?php endif; ?>
<?php /**PATH C:\StoneSystem\resources\views/pages/agendamentoprocessos/chapas.blade.php ENDPATH**/ ?>