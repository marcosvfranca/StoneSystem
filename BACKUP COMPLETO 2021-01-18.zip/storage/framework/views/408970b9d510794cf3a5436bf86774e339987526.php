<?php $user = app('App\User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">Transportadores cadastrados</h4>
                        </div>
                        <div class="card-body">
                            <?php if($user->temAcessoUnico('transportadores', 'C')): ?>
                                <div class="row">
                                    <div class="col-12 text-right">
                                        <a href="<?php echo e(route('transportadores.cadastrar')); ?>" class="btn btn-sm btn-primary"
                                        >Cadastrar tranportador</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="table-responsive">
                                <?php if(!count($transportadores)): ?>
                                    <span>Nenhum transportador cadastrado...</span>
                                <?php else: ?>
                                <table class="table">
                                    <thead class=" text-primary">
                                    <tr>
                                        <th>
                                            Nome
                                        </th>
                                        <th>
                                            Placa
                                        </th>
                                        <th>
                                            Cadastrado em
                                        </th>
                                        <th class="text-right">
                                            &nbsp;&nbsp;
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $transportadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($t->nome); ?>

                                            </td>
                                            <td>
                                                <?php echo e($t->placa); ?>

                                            </td>
                                            <td class="td-actions text-right">
                                                <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('transportadores.alterar', ['id' => encrypt($t->id)])); ?>"
                                                   data-original-title="Editar" title="Editar">
                                                    <i class="material-icons">edit</i>
                                                    <div class="ripple-container"></div>
                                                </a>
                                                <a rel="tooltip" class="btn btn-danger btn-link" href="<?php echo e(route('transportadores.deletar', ['id' => encrypt($t->id)])); ?>"
                                                   data-original-title="Deletar" title="Deletar">
                                                    <i class="material-icons">delete</i>
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'transportadores', 'titlePage' => __('Transportadores')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/index.blade.php ENDPATH**/ ?>
