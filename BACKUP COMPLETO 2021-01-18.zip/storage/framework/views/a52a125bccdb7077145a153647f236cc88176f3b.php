<?php $user = app('App\User'); ?>
<?php $__env->startSection('transportadores'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Transportadores cadastrados</h4>
            </div>
            <div class="card-body">
                <?php if($user->temAcessoUnico('transportadores', 'C')): ?>
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="<?php echo e(route('transportadores.cadastrar')); ?>" class="btn btn-sm btn-warning">
                                <i class="material-icons">commute</i>
                                <div class="ripple-container"></div>
                                <?php echo e(__('Cadastrar transportador')); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <?php if(!count($transportadores)): ?>
                        <span>Nenhum transportador cadastrado...</span>
                    <?php else: ?>
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Nome
                            </th>
                            <th>
                                Placa
                            </th>
                            <th width="180">
                                Quantidade de Blocos
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $transportadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($t->nome); ?>

                                </td>
                                <td div class="text-center">
                                    <?php echo e($t->placa); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($t->blocos()->count()); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e(date('d/m/Y', strtotime($t->created_at))); ?>

                                </td>
                                <td class="td-actions text-right">
                                    <a rel="tooltip" class="btn btn-success" href="<?php echo e(route('transportadores.editar', ['id' => $t->id])); ?>"
                                       data-original-title="<?php echo e(__('Alterar transportador')); ?>" title="<?php echo e(__('Alterar transportador')); ?>">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Alterar transportador')); ?>

                                    </a>
                                    <a rel="tooltip" class="btn btn-danger" href="<?php echo e(route('transportadores.deletar', ['id' => $t->id])); ?>"
                                       data-original-title="<?php echo e(__('Excluir transportador')); ?>" title="<?php echo e(__('Excluir transportador')); ?>"
                                        onclick="return confirm('<?php echo e(__('Deseja realmente excluir este transportador')); ?>')">
                                        <i class="material-icons">delete</i>
                                        <div class="ripple-container"></div>
                                        <?php echo e(__('Excluir transportador')); ?>

                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.transportadores.transportadores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\StoneSystem\resources\views/pages/transportadores/index.blade.php ENDPATH**/ ?>