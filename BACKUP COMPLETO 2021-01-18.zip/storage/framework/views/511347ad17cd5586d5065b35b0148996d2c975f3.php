<div class="sidebar" data-color="orange" data-background-color="white"
     data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
    
    
    <div class="logo">
        <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
            <?php echo e(__(env('APP_NAME'))); ?>

        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <?php if($user->temAcessoUnico('dashboard')): ?>
                <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">
                        <i class="material-icons">dashboard</i>
                        <p><?php echo e(__('Dashboard')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('profile.edit')): ?>
                <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management' || $activePage == 'gruposusuarios') ? ' active' : ''); ?>">
                    <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="false">
                        <i class="material-icons">person</i>
                        <p><?php echo e(__('Funcionários/Setores')); ?>

                            <b class="caret"></b>
                        </p>
                    </a>
                    <div
                        class="collapse <?php echo e(($activePage == 'user-management' || $activePage == 'gruposusuarios') ? ' show' : ''); ?>"
                        id="laravelExample">
                        <ul class="nav">
                            <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                                    <i class="material-icons">group</i>
                                    <span class="sidebar-normal"> <?php echo e(__('Funcionários')); ?> </span>
                                </a>
                            </li>
                            <li class="nav-item<?php echo e($activePage == 'gruposusuarios' ? ' active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('gruposusuarios')); ?>">
                                    <i class="material-icons">groups</i>
                                    <p><?php echo e(__('Setores')); ?></p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('transportadores')): ?>
                <li class="nav-item<?php echo e($activePage == 'transportadores' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('transportadores')); ?>">
                        <i class="material-icons">commute</i>
                        <p><?php echo e(__('Transportadores')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('tipos-blocos')): ?>
                <li class="nav-item<?php echo e($activePage == 'tiposblocos' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('tiposblocos')); ?>">
                        <i class="material-icons">view_module</i>
                        <p><?php echo e(__('Classificação de blocos')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('blocos')): ?>
                <li class="nav-item<?php echo e($activePage == 'blocos' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('blocos')); ?>">
                        <i class="material-icons">view_agenda</i>
                        <p><?php echo e(__('Blocos')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('estados_chapas')): ?>
                <li class="nav-item<?php echo e($activePage == 'estados_chapas' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('estados-chapas.index')); ?>">
                        <i class="material-icons">calendar_view_day</i>
                        <p><?php echo e(__('Estados de chapas')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('espessuras_chapas')): ?>
                <li class="nav-item<?php echo e($activePage == 'espessuras_chapas' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('espessuras-chapas.index')); ?>">
                        <i class="material-icons">aspect_ratio</i>
                        <p><?php echo e(__('Espessuras de chapas')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('observacoes_chapas')): ?>
                <li class="nav-item<?php echo e($activePage == 'observacoes_chapas' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('observacoes-chapas.index')); ?>">
                        <i class="material-icons">flip_to_front</i>
                        <p><?php echo e(__('Observações de chapas')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('tipo_material_processos')): ?>
                <li class="nav-item<?php echo e($activePage == 'tipo_material_processos' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('tipo-material-processos.index')); ?>">
                        <i class="material-icons">library_books</i>
                        <p><?php echo e(__('Material de processos')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('motivos')): ?>
                <li class="nav-item<?php echo e($activePage == 'motivos' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('motivos.index')); ?>">
                        <i class="material-icons mt-3">cancel_presentation</i>
                        <p style="white-space: normal;"><?php echo e(__('Motivos operações de processos')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('processos')): ?>
                <li class="nav-item<?php echo e($activePage == 'processos' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('processos.index')); ?>">
                        <i class="material-icons">insights</i>
                        <p><?php echo e(__('Processos')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('agendamento_processos')): ?>
                <li class="nav-item<?php echo e($activePage == 'agendamento_processos' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('agendamento-processos.index')); ?>">
                        <i class="material-icons">note_add</i>
                        <p><?php echo e(__('Agendar processos')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($user->temAcessoUnico('executar_processos')): ?>
                <li class="nav-item<?php echo e($activePage == 'executar_processos' ? ' active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('executar-processos.index')); ?>">
                        <i class="material-icons">perm_data_setting</i>
                        <p><?php echo e(__('Executar processos')); ?></p>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\StoneSystem\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>