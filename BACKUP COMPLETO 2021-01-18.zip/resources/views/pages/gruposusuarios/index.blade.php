@extends('pages.gruposusuarios.gruposusuarios')
@inject('user','App\User')
@section('gruposusuarios')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Setores</h4>
            </div>
            <div class="card-body">
                @if($user->temAcessoUnico('gruposusuarios', 'C'))
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="{{ route('gruposusuarios.cadastrar') }}" class="btn btn-sm btn-warning">
                                <i class="material-icons">groups</i>
                                <div class="ripple-container"></div>
                                {{ __('Cadastrar setor') }}</a>
                        </div>
                    </div>
                @endif
                <div class="table-responsive">
                    @if(!count($gruposusuarios))
                        <span>Nenhum setor cadastrado...</span>
                    @else
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Nome
                            </th>
                            <th class="text-center">
                                Administrador?
                            </th>
                            <th class="text-right">
                                Quantidade de funcionários
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($gruposusuarios as $g)
                            <tr>
                                <td>
                                    {{ $g->nome }}
                                </td>
                                <td class="text-center">
                                    {{ $g->admin == 'S' ? 'Sim' : 'Não' }}
                                </td>
                                <td class="text-right">
                                    {{ $g->usuarios()->count() }}
                                </td>
                                <td class="td-actions text-right">
                                    @if($user->temAcessoUnico('gruposusuarios', 'A'))
                                    <a rel="tooltip" class="btn btn-success" href="{{ route('gruposusuarios.editar', ['id' => $g->id]) }}"
                                       data-original-title="{{ __('Gerênciar setor') }}" title="{{ __('Gerênciar setor') }}">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Gerênciar setor') }}
                                    </a>
                                    @endif
                                    @if($user->temAcessoUnico('gruposusuarios', 'E'))
                                    <a rel="tooltip" class="btn btn-danger" href="{{ route('gruposusuarios.deletar', ['id' => $g->id]) }}"
                                       data-original-title="{{ __('Excluir setor') }}" title="{{ __('Excluir setor') }}"
                                       onclick="return confirm('Confirma a exclusão deste setor?');">
                                        <i class="material-icons">delete</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Excluir setor') }}
                                    </a>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
