@inject('user','App\User')
@if($chapas->count())
    <div class="table-responsive">
        <table class="table">
            <thead class="text-warning">
                <tr>
                    <th class="text-center">
                        Numeração /
                        <br>
                        Estado
                    </th>
                    <th>
                        Observações
                    </th>
                    <th>
                        Espessura
                    </th>
                    <th>
                        Largura
                    </th>
                    <th>
                        Comprimento
                    </th>
                    @if($user->temAcessoUnico('chapas', 'E'))
                    <th></th>
                    @endif
                </tr>
            </thead>
            <tbody>
            @foreach($chapas as $c)
            <tr>
                <td>
                    <div class="col-12 font-weight-bold">
                        {{ $c->numeracao }}
                    </div>
                    @if($c->estados()->count())
                    <div class="col-12">
                        <ul>
                            @foreach($c->estados()->get() as $e)
                            <li>{{ $e->descricao }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                </td>
                <td>
                    @if($c->observacoes()->count())
                    <ul>
                        @foreach($c->observacoes()->get() as $o)
                            <li>{{ $o->apelido }}</li>
                        @endforeach
                    </ul>
                    @else
                        -
                    @endif
                </td>
                <td>
                    {{ $c->espessura()->first()->descricao }}
                </td>
                <td>
                    {{ $c->comprimento }}
                </td>
                <td>
                    {{ $c->largura }}
                </td>
                @if($user->temAcessoUnico('chapas', 'E'))
                <td class="td-actions text-right">
{{--                @if($user->temAcessoUnico('chapas', 'A'))--}}
{{--                    <a rel="tooltip" class="btn btn-success"--}}
{{--                       href="{{ route('chapas.edit', ['chapa' => $c->id]) }}"--}}
{{--                       data-original-title="{{ __('Alterar chapa') }}" title="{{ __('Alterar chapa') }}">--}}
{{--                        <i class="material-icons">edit</i>--}}
{{--                        <div class="ripple-container"></div>--}}
{{--                        {{ __('Alterar chapa') }}--}}
{{--                    </a>--}}
{{--                @endif--}}
                @if($user->temAcessoUnico('chapas', 'E'))
                    <form method="POST"
                          action="{{ route('chapas.destroy', ['chapa' => $c->id]) }}"
                          class="d-inline-block formDeleteChapa"
                          data-message='Chapa "{{ $c->numeracao }}" excluída com sucesso'
                          data-message-error="Erro ao excluir chapa, tente novamente">
                        {{ csrf_field() }}
                        {{ method_field('DELETE') }}
                        <div class="form-group">
                            <button rel="tooltip" class="btn btn-danger" type="submit"
                                    data-original-title="{{ __('Excluir chapa') }}" title="{{ __('Excluir chapa') }}"
                                    onclick="return confirm('Tem certeza que deseja excluir a chapa de numeração: {{ $c->numeracao }}?')"
                                    data-original-text='<i class="material-icons">delete</i>
                                <div class="ripple-container"></div>
                                {{ __('Excluir chapa') }}'>
                                <i class="material-icons">delete</i>
                                <div class="ripple-container"></div>
                                {{ __('Excluir chapa') }}
                            </button>
                        </div>
                    </form>
                @endif
                </td>
                @endif
            </tr>
            </tbody>
            @endforeach
        </table>
    </div>
@else
    <div class="alert alert-danger">Nenhuma chapa encontrada</div>
@endif
