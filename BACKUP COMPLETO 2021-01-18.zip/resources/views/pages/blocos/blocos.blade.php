@extends('layouts.containerfluid', ['activePage' => 'blocos', 'titlePage' => __('Blocos')])
@section('containerfluid')
  @yield('blocos')
@endsection
