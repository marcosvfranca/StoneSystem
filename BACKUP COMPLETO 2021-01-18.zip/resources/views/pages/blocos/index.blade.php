@extends('pages.blocos.blocos')
@inject('user','App\User')
@section('blocos')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Blocos cadastrados</h4>
            </div>
            <div class="card-body">
                @if($user->temAcessoUnico('blocos', 'C'))
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="{{ route('blocos.cadastrar') }}" class="btn btn-sm btn-warning">
                                <i class="material-icons">view_agenda</i>
                                <div class="ripple-container"></div>
                                {{ __('Cadastrar bloco') }}</a>
                        </div>
                    </div>
                @endif
                <div class="table-responsive">
                    @if(!count($blocos))
                        <span>Nenhum bloco cadastrado...</span>
                    @else
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Numeração
                            </th>
                            <th class="text-center">
                                Transportador /
                                <br>
                                Placa
                            </th>
                            <th>
                                Classificação
                            </th>
                            <th class="text-center">
                                Quantidade de chapas
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($blocos as $b)
                            <tr>
                                <td>
                                    {{ $b->numeracao }}
                                </td>
                                <td class="text-center">
                                    {{ $b->transportadores()->first()->nome ?? 'Sem transportador'}}
                                    <br>
                                    {{ $b->transportadores()->first()->placa ?? 'Sem transportador'}}
                                </td>
                                <td>
                                    {{ $b->tiposBlocos()->first()->descricao ?? 'Sem classificação de bloco'}}
                                </td>
                                <td class="text-center">
                                    {{ $b->chapas()->count() }}
                                </td>
                                <td class="text-center">
                                    {{ date('d/m/Y', strtotime($b->created_at)) }}
                                </td>
                                <td class="td-actions text-right">
                                    @if($user->temAcessoUnico('blocos', 'A'))
                                    <a rel="tooltip" class="btn btn-success" href="{{ route('blocos.editar', ['id' => $b->id]) }}"
                                       data-original-title="{{ __('Cadastrar chapas') }}" title="{{ __('Cadastrar chapas') }}">
                                        <i class="material-icons">equalizer</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Gerenciar chapas') }}
                                    </a>
                                    @endif
                                    @if($user->temAcessoUnico('blocos', 'E'))
                                    <a rel="tooltip" class="btn btn-danger" href="{{ route('blocos.deletar', ['id' => $b->id]) }}"
                                       data-original-title="{{ __('Excluir bloco') }}" title="{{ __('Excluir bloco') }}">
                                        <i class="material-icons">delete</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Excluir bloco') }}
                                    </a>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
