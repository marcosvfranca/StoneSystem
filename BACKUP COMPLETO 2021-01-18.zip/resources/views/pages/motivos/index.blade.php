@extends('pages.motivos.padrao')
@inject('user','App\User')
@section('padrao')
<div class="row">
    <div class="col-md-12">
        @if (session('status') or session('error'))
            @push('js')
                <script>
                    $.notify({
                        icon: "cancel_presentation",
                        message: "{{ session('status') ?? session('error')  }}"
                    },{
                        type: @if(session('status')) 'success' @else 'danger' @endif,
                        withtimer: 500,
                        placement: {
                            from: 'top',
                            align: 'center'
                        }
                    });
                </script>
            @endpush
        @endif
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Motivos de operações de processos</h4>
            </div>
            <div class="card-body">
                @if($user->temAcessoUnico('motivos', 'C'))
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="{{ route('motivos.create') }}" class="btn btn-sm btn-warning">
                                <i class="material-icons">cancel_presentation</i>
                                <div class="ripple-container"></div>
                                {{ __('Cadastrar motivo de operação de processo') }}</a>
                        </div>
                    </div>
                @endif
                <div class="table-responsive">
                    @if(!count($motivos))
                        <span>Nenhum  motivo operação de processo cadastrado...</span>
                    @else
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Motivo
                            </th>
                            <th class="text-right" width="200">
                                Presente em (Processos)
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($motivos as $m)
                            <tr>
                                <td>
                                    {{ $m->motivo }}
                                </td>
                                <td class="text-right">
                                    corrigir
{{--                                    {{ $m->processos()->count() }}--}}
                                </td>
                                <td class="text-center">
                                    {{ date('d/m/Y', strtotime($m->created_at)) }}
                                </td>
                                <td class="td-actions text-right">
                                    @if(auth()->user()->temAcessoUnico('motivos', 'A'))
                                    <a rel="tooltip" class="btn btn-success" href="{{ route('motivos.edit', ['motivo' => $m->id]) }}"
                                       data-original-title="{{ __('Alterar motivo') }}" title="{{ __('Alterar motivo') }}">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Alterar motivo') }}
                                    </a>
                                    @endif
                                    @if(auth()->user()->temAcessoUnico('motivos', 'E'))
                                        <form action="{{ route('motivos.destroy', ['motivo' => $m->id]) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="{{ __('Excluir motivo') }}" title="{{ __('Excluir motivo') }}"
                                               onclick="return confirm('Deseja excluir esse motivo de cancelamento de processo?')">
                                                <i class="material-icons">delete</i>
                                                {{ __('Excluir motivo') }}
                                            </button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
