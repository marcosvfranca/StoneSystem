@extends('pages.espessuraschapas.padrao')
@inject('user','App\User')
@section('padrao')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Espessuras de chapas cadastrados</h4>
            </div>
            <div class="card-body">
                @if($user->temAcessoUnico('espessuras_chapas', 'C'))
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="{{ route('espessuras-chapas.create') }}" class="btn btn-sm btn-warning">
                                <i class="material-icons">aspect_ratio</i>
                                <div class="ripple-container"></div>
                                {{ __('Cadastrar espessura de chapa') }}</a>
                        </div>
                    </div>
                @endif
                <div class="table-responsive">
                    @if(!count($espessurasChapas))
                        <span>Nenhuma espessura de chapa cadastrada...</span>
                    @else
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Espessura
                            </th>
                            <th class="text-right" width="200">
                                Presente em (Chapas)
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($espessurasChapas as $e)
                            <tr>
                                <td>
                                    {{ $e->descricao }}
                                </td>
                                <td class="text-right">
                                    {{ $e->chapas()->count() }}
                                </td>
                                <td class="text-center">
                                    {{ date('d/m/Y', strtotime($e->created_at)) }}
                                </td>
                                <td class="td-actions text-right">
                                    @if($user->temAcessoUnico('espessuras_chapas', 'A'))
                                    <a rel="tooltip" class="btn btn-success" href="{{ route('espessuras-chapas.edit', ['espessuras_chapa' => $e->id]) }}"
                                       data-original-title="{{ __('Alterar espessura de chapa') }}" title="{{ __('Alterar espessura de chapa') }}">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Alterar espessura de chapa') }}
                                    </a>
                                    @endif
                                    @if($user->temAcessoUnico('espessuras_chapas', 'E'))
                                        <form action="{{ route('espessuras-chapas.destroy', ['espessuras_chapa' => $e->id]) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="{{ __('Excluir espessura de chapa') }}" title="{{ __('Excluir espessura de chapa') }}"
                                               onclick="return confirm('Deseja excluir essa espessura de chapa?')">
                                                <i class="material-icons">delete</i>
                                                {{ __('Excluir espessura de chapa') }}
                                            </button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
