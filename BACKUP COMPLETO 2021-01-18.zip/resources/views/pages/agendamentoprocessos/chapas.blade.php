@if(count($blocos))
<div class="table-responsive">
    <table class="table">
        <tbody>
        @foreach($blocos as $bloco)
            <tr class="bg-light">
                <th>
                    <input type="checkbox" class="checkbox checkboxBloco" data-id="{{ $bloco->id }}">
                </th>
                <th>
                    Bloco nº: {{ $bloco->numeracao }}
                </th>
                <th>
                    Categoria: {{ $bloco->tiposBlocos()->first()->descricao }}
                </th>
                <th>
                    Transportador: {{ $bloco->transportadores()->first()->nome }} - {{ $bloco->transportadores()->first()->placa }}
                </th>
                <th>
                    &nbsp;
                </th>
            </tr>
            @foreach($bloco->chapas()
                        ->whereNotExists(function ($q) {
                            $q
                            ->select(\Illuminate\Support\Facades\DB::raw(1))
                            ->from('chapa_bloco_agendamento_processos')
                            ->whereRaw('chapa_bloco_agendamento_processos.chapas_bloco_id = chapas_blocos.id')
                            ;
                        })
                        ->get() as $chapa)
                <tr>
                    <td>
                        <input type="checkbox" class="checkbox checkboxChapa" data-chapa-id="{{ $chapa->id }}" data-bloco-id="{{ $bloco->id }}">
                    </td>
                    <td>
                        Chapa nº: {{ $chapa->numeracao }}
                    </td>
                    <td>
                        Espessura: {{ $chapa->espessura()->first()->descricao }}
                    </td>
                    <td>
                        Comprimento: {{ $chapa->comprimento }}
                    </td>
                    <td>
                        Largura: {{ $chapa->largura }}
                    </td>
                </tr>
            @endforeach
        @endforeach
        </tbody>
    </table>
</div>
@else
    <div class="alert alert-danger">
        Nada encontrado...
    </div>
@endif
