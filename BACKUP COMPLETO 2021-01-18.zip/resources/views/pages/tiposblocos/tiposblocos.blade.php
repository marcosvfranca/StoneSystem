@extends('layouts.containerfluid', ['activePage' => 'tiposblocos', 'titlePage' => __('Classificação de blocos')])
@section('containerfluid')
  @yield('tiposblocos')
@endsection
