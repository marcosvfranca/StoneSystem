@extends('pages.processos.padrao')
@inject('user','App\User')
@section('padrao')
<div class="row">
    <div class="col-md-12">
        @if (session('status') or session('error'))
            @push('js')
                <script>
                    $.notify({
                        icon: "insights",
                        message: "{{ session('status') ?? session('error')  }}"
                    },{
                        type: @if(session('status')) 'success' @else 'danger' @endif,
                        withtimer: 500,
                        placement: {
                            from: 'top',
                            align: 'center'
                        }
                    });
                </script>
            @endpush
        @endif
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Processos</h4>
            </div>
            <div class="card-body">
                @if($user->temAcessoUnico('processos', 'C'))
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="{{ route('processos.create') }}" class="btn btn-sm btn-warning">
                                <i class="material-icons">insights</i>
                                <div class="ripple-container"></div>
                                {{ __('Cadastrar processo') }}</a>
                        </div>
                    </div>
                @endif
                <div class="table-responsive">
                    @if(!count($processos))
                        <span>Nenhum processo cadastrado...</span>
                    @else
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Processo
                            </th>
                            <th class="text-right" width="50">
                                Exige material
                            </th>
                            <th class="text-right" width="50">
                                Ultimo processo
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($processos as $p)
                            <tr>
                                <td>
                                    {{ $p->nome }}
                                </td>
                                <td class="text-right">
                                    {{ $p->exige_material == 'S' ? 'Sim' : 'Não' }}
                                </td>
                                <td class="text-right">
                                    {{ $p->ultimo_processo == 'S' ? 'Sim' : 'Não' }}
                                </td>
                                <td class="text-center">
                                    {{ date('d/m/Y', strtotime($p->created_at)) }}
                                </td>
                                <td class="td-actions text-right">
                                    @if($user->temAcessoUnico('processos', 'A'))
                                    <a rel="tooltip" class="btn btn-success" href="{{ route('processos.edit', ['processo' => $p->id]) }}"
                                       data-original-title="{{ __('Alterar processo') }}" title="{{ __('Alterar processo') }}">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Alterar processo') }}
                                    </a>
                                    @endif
                                    @if($user->temAcessoUnico('processos', 'E'))
                                        <form action="{{ route('processos.destroy', ['processo' => $p->id]) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="{{ __('Excluir processo') }}" title="{{ __('Excluir processo') }}"
                                               onclick="return confirm('Deseja excluir este processo?')">
                                                <i class="material-icons">delete</i>
                                                {{ __('Excluir processo') }}
                                            </button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
