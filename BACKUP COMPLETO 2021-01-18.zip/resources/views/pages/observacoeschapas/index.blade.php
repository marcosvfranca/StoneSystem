@extends('pages.observacoeschapas.padrao')
@inject('user','App\User')
@section('padrao')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-warning">
                <h4 class="card-title ">Observações de chapas cadastrados</h4>
            </div>
            <div class="card-body">
                @if($user->temAcessoUnico('observacoes_chapas', 'C'))
                    <div class="row">
                        <div class="col-12 text-right">
                            <a href="{{ route('observacoes-chapas.create') }}" class="btn btn-sm btn-warning">
                                <i class="material-icons">flip_to_front</i>
                                <div class="ripple-container"></div>
                                {{ __('Cadastrar observação de chapa') }}</a>
                        </div>
                    </div>
                @endif
                <div class="table-responsive">
                    @if(!count($observacoesChapas))
                        <span>Nenhuma observação de chapa cadastrada...</span>
                    @else
                    <table class="table">
                        <thead class=" text-warning">
                        <tr>
                            <th>
                                Observação
                            </th>
                            <th>
                                Apelido
                            </th>
                            <th class="text-right" width="200">
                                Presente em (Chapas)
                            </th>
                            <th class="text-center">
                                Cadastrado em
                            </th>
                            <th class="text-right" width="200">
                                &nbsp;&nbsp;
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($observacoesChapas as $o)
                            <tr>
                                <td>
                                    {{ $o->descricao }}
                                </td>
                                <td>
                                    {{ $o->apelido }}
                                </td>
                                <td class="text-right">
                                    {{ $o->chapas()->count() }}
                                </td>
                                <td class="text-center">
                                    {{ date('d/m/Y', strtotime($o->created_at)) }}
                                </td>
                                <td class="td-actions text-right" width="360">
                                    @if($user->temAcessoUnico('observacoes_chapas', 'A'))
                                    <a rel="tooltip" class="btn btn-success" href="{{ route('observacoes-chapas.edit', ['observacoes_chapa' => $o->id]) }}"
                                       data-original-title="{{ __('Alterar observação de chapa') }}" title="{{ __('Alterar observação de chapa') }}">
                                        <i class="material-icons">edit</i>
                                        <div class="ripple-container"></div>
                                        {{ __('Alterar observação') }}
                                    </a>
                                    @endif
                                    @if($user->temAcessoUnico('observacoes_chapas', 'E'))
                                        <form action="{{ route('observacoes-chapas.destroy', ['observacoes_chapa' => $o->id]) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" rel="tooltip" class="btn btn-danger"
                                               data-original-title="{{ __('Excluir observação de chapa') }}" title="{{ __('Excluir observação de chapa') }}"
                                               onclick="return confirm('{{ __('Deseja excluir essa observação de chapa?') }}')">
                                                <i class="material-icons">delete</i>
                                                {{ __('Excluir observação') }}
                                            </button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
