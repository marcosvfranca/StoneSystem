@extends('pages.relatorios.padrao', ['activePage' => 'relatorio_estoque_chapas_serradas', 'titlePage' => 'Estoque de chapas serradas'])
@section('relatorio')
    <div class="card mt-2">
        <h4 class="card-header">Filtragem:</h4>
        <div class="card-body">
            <form>
                <div class="row">
                    <div class="col-5">
                        <label>Numeração do bloco</label>
                        <input class="form-control" placeholder="Numeração do bloco" name="numeracao"
                               value="{{ request()->get('numeracao') ?? null }}">
                    </div>
                    <div class="col-5">
                        <label>Material do bloco</label>
                        <select class="form-control" name="tipos_blocos">
                            <option value="">Todos...</option>
                            @foreach($tipos_blocos as $t)
                                <option value="{{ $t->id }}"
                                        @if((request()->get('tipos_blocos') ?? null) == $t->id ) selected @endif>{{ $t->descricao }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row mt-2 ocultarNaImpressao">
                    <div class="col-2">
                        <button type="submit" class="btn btn-block btn-warning">Aplicar filtros</button>
                    </div>
                    <div class="col-1">
                        <button type="button" onclick="imprimir()" class="btn btn-block btn-primary">Imprimir</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    @if(!count($chapas_serradas))
        <div class="container">
            <div class="alert alert-danger mt-3">Nenhuma chapa serrada encontrada...</div>
        </div>
    @else
        <div style="border: 0;border-radius: 5px;padding: 5px;">
            <table class="table" border="1">
                @foreach($chapas_serradas as $cs)
                    <thead class=" text-warning">
                    <tr>
                        <th>
                            Numeração do bloco
                        </th>
                        <th>
                            Quantidade de chapas
                        </th>
                        <th>
                            Material do bloco
                        </th>
                        <th>
                            Qualidade da serrada
                        </th>
                        <th class="text-center">
                            Cadastrado em
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>
                            {{ $cs->numeracao }}
                        </td>
                        <td>
                            {{ $cs->chapas()->count() }}
                        </td>
                        <td>
                            {{ $cs->tiposBlocos()->first()->descricao }}
                        </td>
                        <td>
                            <ul>
                                @foreach($cs->observacoes()->get() as $o)
                                    <li>
                                        {{ $o->observacao()->first()->descricao }}
                                    </li>
                                @endforeach
                            </ul>
                        </td>
                        <td class="text-center">
                            {{ date('d/m/Y', strtotime($cs->created_at)) }}
                        </td>
                    </tr>
                    <td colspan="5">
                        <table style="width: 100%;" border="1">
                            <thead class=" text-warning">
                            <tr>
                                <th>
                                    Numeração da chapa
                                </th>
                                <th>
                                    Espessura
                                </th>
                                <th>
                                    Comprimento
                                </th>
                                <th>
                                    Altura
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($cs->chapas()->whereNull('chapas_bloco_id')->orderByRaw('CAST(numeracao as SIGNED INTEGER)')->get() as $c)
                                <tr @if($c->espessura()->first()->cor or $c->espessura()->first()->cor_fonte) style="background-color: {{ $c->espessura()->first()->cor }};color: {{ $c->espessura()->first()->cor_fonte }};"
                                    @endif>
                                    <td>
                                        {{ $c->numeracao }}
                                    </td>
                                    <td>
                                        {{ $c->espessura()->first()->descricao }}
                                    </td>
                                    <td>
                                        {{ $c->comprimento }}
                                    </td>
                                    <td>
                                        {{ $c->altura }}
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </td>
                    @endforeach
                    </tbody>
            </table>
        </div>
    @endif
@endsection
