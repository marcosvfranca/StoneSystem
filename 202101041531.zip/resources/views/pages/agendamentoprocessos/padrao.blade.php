@extends('layouts.containerfluid', ['activePage' => 'agendamento_processos', 'titlePage' => __('Agenda de processos')])
@section('containerfluid')
  @yield('padrao')
@endsection
