@extends('layouts.containerfluid', ['activePage' => 'observacoes_chapas', 'titlePage' => __('Observações das chapas')])
@section('containerfluid')
  @yield('padrao')
@endsection
