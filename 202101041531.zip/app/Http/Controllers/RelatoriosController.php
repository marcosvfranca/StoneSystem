<?php

namespace App\Http\Controllers;

use App\ChapasSerradas;
use App\TiposBlocos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RelatoriosController extends Controller
{
    public function estoqueChapasSerradas()
    {
        $this->temAcesso('relatorio_estoque_chapas_serradas');
        $data = request()->all();
        $chapas_serradas = ChapasSerradas::whereExists(function ($query) {
            $query->select(DB::raw(1))
                ->from('itens_chapas_serradas')
                ->whereColumn('itens_chapas_serradas.chapas_serradas_id', 'chapas_serradas.id')
                ->whereNull('chapas_bloco_id');
        })->limit(100);

        if (isset($data['numeracao']))
            $chapas_serradas->where('numeracao', 'like', '%' . $data['numeracao'] . '%');

        if (isset($data['tipos_blocos']))
            $chapas_serradas->where('tipos_blocos_id', $data['tipos_blocos']);

        return view('pages.relatorios.estoque-chapas-serradas', [
            'chapas_serradas' => $chapas_serradas->get(),
            'tipos_blocos' => TiposBlocos::all()
        ]);
    }
}
